import React from 'react';
import { ShieldCheck, ShieldAlert, AlertTriangle, CheckCircle2, Lightbulb } from 'lucide-react';
import { FlakinessAudit } from '../types';

interface FlakinessAuditCardProps {
  audit: FlakinessAudit;
}

export const FlakinessAuditCard: React.FC<FlakinessAuditCardProps> = ({ audit }) => {
  const getGradeColor = (grade: FlakinessAudit['grade']) => {
    switch (grade) {
      case 'A+':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      case 'A':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'B':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      case 'C':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      default:
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Locator Flakiness Risk Audit
          </h4>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-[11px] text-slate-400 font-medium">Stability Score:</span>
          <span className="font-mono text-xs font-bold text-white">{audit.score}/100</span>
          <span className={`text-xs font-bold px-2 py-0.5 rounded-md border font-mono ${getGradeColor(audit.grade)}`}>
            Grade {audit.grade}
          </span>
        </div>
      </div>

      {/* Audit Checklist */}
      <div className="grid grid-cols-1 gap-2 text-xs">
        {audit.checks.map((check, i) => (
          <div
            key={i}
            className={`p-2.5 rounded-xl border flex items-start space-x-2.5 transition ${
              check.status === 'pass'
                ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                : check.status === 'warn'
                ? 'bg-amber-950/20 border-amber-800/40 text-amber-200'
                : 'bg-rose-950/20 border-rose-800/40 text-rose-200'
            }`}
          >
            {check.status === 'pass' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
            ) : check.status === 'warn' ? (
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            ) : (
              <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
            )}
            <div className="space-y-0.5">
              <span className="font-semibold text-white block">{check.name}</span>
              <p className="text-[11px] leading-relaxed text-slate-400">{check.detail}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Proactive QA Recommendations */}
      {audit.recommendations.length > 0 && (
        <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-800/40 text-xs space-y-1.5">
          <div className="flex items-center space-x-1.5 text-indigo-300 font-semibold text-[11px] uppercase tracking-wide">
            <Lightbulb className="w-3.5 h-3.5 text-indigo-400" />
            <span>Architect Recommendations for Flake-Free Execution:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
            {audit.recommendations.map((rec, i) => (
              <li key={i}>{rec}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
