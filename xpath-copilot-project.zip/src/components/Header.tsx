import React from 'react';
import { Target, BookOpen, Code2, Layers, Cpu, Boxes, Globe, FolderArchive, Download } from 'lucide-react';

interface HeaderProps {
  viewMode: 'studio' | 'harvester' | 'json';
  onToggleViewMode: (mode: 'studio' | 'harvester' | 'json') => void;
  onOpenRules: () => void;
  onOpenUrlModal: () => void;
  onOpenExportModal: () => void;
  aiSource?: string;
}

export const Header: React.FC<HeaderProps> = ({
  viewMode,
  onToggleViewMode,
  onOpenRules,
  onOpenUrlModal,
  onOpenExportModal,
  aiSource,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur-md sticky top-0 z-30 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Brand & Title */}
        <div className="flex items-center space-x-3.5">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/10">
              <Target className="w-5 h-5 text-white" />
            </div>
            <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 ring-2 ring-slate-950"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                XPath & Selector Copilot
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300">
                  State-of-the-Art QA
                </span>
              </h1>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              Enterprise Locator Architect for Selenium, Playwright & Cypress
            </p>
          </div>
        </div>

        {/* Priority Hierarchy Visual Indicator */}
        <div className="hidden 2xl:flex items-center space-x-1.5 text-[11px] bg-slate-900/80 border border-slate-800/80 rounded-lg p-1">
          <span className="text-slate-500 px-2 font-mono text-[10px] uppercase font-bold">Priority:</span>
          <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 font-medium border border-emerald-500/20" title="Tier 1: data-testid, data-qa">
            1. QA Attributes
          </span>
          <span className="text-slate-600">›</span>
          <span className="px-2 py-0.5 rounded bg-blue-500/15 text-blue-400 font-medium border border-blue-500/20" title="Tier 2: Unique static ID & Name">
            2. Unique Attr
          </span>
          <span className="text-slate-600">›</span>
          <span className="px-2 py-0.5 rounded bg-purple-500/15 text-purple-400 font-medium border border-purple-500/20" title="Tier 3: normalize-space() text">
            3. Semantic Text
          </span>
          <span className="text-slate-600">›</span>
          <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 font-medium border border-amber-500/20" title="Tier 4: Relational & Axes">
            4. Axis Traversal
          </span>
          <span className="text-slate-600">›</span>
          <span className="px-2 py-0.5 rounded bg-rose-500/15 text-rose-400 font-medium border border-rose-500/20" title="Tier 5: Partial match contains()">
            5. Partial Match
          </span>
        </div>

        {/* Action Controls & Navigation Modes */}
        <div className="flex flex-wrap items-center gap-2">
          {aiSource && (
            <div className="hidden xl:flex items-center space-x-1 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs text-slate-400">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Engine: <strong className="text-slate-300 font-mono">{aiSource}</strong></span>
            </div>
          )}

          {/* Export ZIP for VS Code Button */}
          <button
            onClick={onOpenExportModal}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-700/60 transition shadow-sm"
          >
            <FolderArchive className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export ZIP for VS Code</span>
          </button>

          {/* Live URL Fetch Button */}
          <button
            onClick={onOpenUrlModal}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/60 transition shadow-sm"
          >
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span>Fetch URL</span>
          </button>

          <button
            onClick={onOpenRules}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/60 transition shadow-sm"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>Strategy Rules</span>
          </button>

          {/* Mode Switcher */}
          <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => onToggleViewMode('studio')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                viewMode === 'studio'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Copilot Studio</span>
            </button>
            <button
              onClick={() => onToggleViewMode('harvester')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                viewMode === 'harvester'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Boxes className="w-3.5 h-3.5" />
              <span>POM Harvester</span>
            </button>
            <button
              onClick={() => onToggleViewMode('json')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                viewMode === 'json'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Raw JSON</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
