import React, { useState } from 'react';
import { Check, Copy, Download, Terminal, CheckCircle2, FileCode } from 'lucide-react';
import { CopilotResult } from '../types';

interface RawJsonViewerProps {
  result: CopilotResult | null;
  html: string;
  targetFunctionality: string;
}

export const RawJsonViewer: React.FC<RawJsonViewerProps> = ({
  result,
  html,
  targetFunctionality,
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);

  const rawJsonObject = result ? {
    target_functionality: result.target_functionality,
    best_xpath: result.best_xpath,
    strategy_used: result.strategy_used,
    alternative_xpaths: result.alternative_xpaths,
    alternative_css_selector: result.alternative_css_selector,
    playwright_semantic_locator: result.playwright_semantic_locator,
    confidence_score: typeof result.confidence_score === 'number' 
      ? result.confidence_score.toString() 
      : result.confidence_score,
    explanation: result.explanation,
  } : null;

  const jsonString = rawJsonObject ? JSON.stringify(rawJsonObject, null, 2) : '';

  const copyJson = () => {
    if (!jsonString) return;
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJson = () => {
    if (!jsonString) return;
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `xpath-copilot-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const curlSnippet = `curl -X POST https://${window.location.host}/api/generate-xpath \\
  -H "Content-Type: application/json" \\
  -d '${JSON.stringify({ html: html.slice(0, 100) + '...', targetFunctionality })}'`;

  const copyCurl = () => {
    navigator.clipboard.writeText(curlSnippet);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <FileCode className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-white">Strict Output Format: Raw JSON</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-medium">
              RFC 8259 Compliant
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Zero markdown blocks, zero conversational text — exact production payload for CI/CD pipelines & automation agents.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={downloadJson}
            disabled={!result}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 disabled:opacity-40 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download JSON</span>
          </button>
          <button
            onClick={copyJson}
            disabled={!result}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 shadow-sm transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Raw JSON'}</span>
          </button>
        </div>
      </div>

      {/* JSON Viewer */}
      {result ? (
        <div className="relative">
          <pre className="p-4 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-emerald-300 overflow-x-auto leading-relaxed max-h-[500px]">
            {jsonString}
          </pre>
        </div>
      ) : (
        <div className="p-8 text-center bg-slate-950 border border-slate-800 rounded-xl text-slate-400 text-xs">
          No JSON output yet. Click <strong>Generate</strong> in the Copilot Studio to produce the validated JSON response.
        </div>
      )}

      {/* Direct API Integration / cURL */}
      <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            CI/CD & Headless API Integration (cURL)
          </span>
          <button
            onClick={copyCurl}
            className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
          >
            {copiedCurl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copiedCurl ? 'Copied' : 'Copy cURL'}</span>
          </button>
        </div>
        <pre className="font-mono text-[11px] text-slate-400 p-2.5 rounded bg-slate-900 border border-slate-800/80 overflow-x-auto select-all">
          {curlSnippet}
        </pre>
      </div>
    </div>
  );
};
