import React from 'react';
import { X, CheckCircle2, AlertTriangle, ShieldAlert, Award, FileCode } from 'lucide-react';

interface SpecificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SpecificationModal: React.FC<SpecificationModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-2.5">
            <Award className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-bold text-white">Selection Hierarchy & Anti-Pattern Specification</h2>
              <p className="text-xs text-slate-400">Strict architectural guidelines used by the Copilot</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
          {/* Hierarchy */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-400" />
              Strict Order of Priority (1 to 5)
            </h3>
            <div className="space-y-2.5">
              <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
                <div className="flex items-center justify-between font-semibold text-emerald-300 mb-1">
                  <span>1. Standard QA Attributes (Gold Standard)</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Highest Stability</span>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  Target explicitly configured testing hooks: <code className="text-emerald-300 font-mono">data-testid</code>, <code className="text-emerald-300 font-mono">data-qa</code>, <code className="text-emerald-300 font-mono">data-cy</code>, <code className="text-emerald-300 font-mono">data-test</code>.
                </p>
                <div className="text-xs font-mono bg-slate-950/80 p-2 rounded text-emerald-400">
                  //*[@data-testid='value']
                </div>
              </div>

              <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-800/40">
                <div className="flex items-center justify-between font-semibold text-blue-300 mb-1">
                  <span>2. Unique Persistent Attributes</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">Static & Unique</span>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  Unique <code className="text-blue-300 font-mono">id</code>, <code className="text-blue-300 font-mono">name</code>, or <code className="text-blue-300 font-mono">placeholder</code> (ensuring they are static, NOT auto-generated hashes like <code className="text-rose-400">input_9824a</code>).
                </p>
                <div className="text-xs font-mono bg-slate-950/80 p-2 rounded text-blue-400">
                  //input[@id='username'] | //input[@name='email']
                </div>
              </div>

              <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-800/40">
                <div className="flex items-center justify-between font-semibold text-purple-300 mb-1">
                  <span>3. Semantic Text & Space Normalization</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">Resilient Text</span>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  Visible inner text using <code className="text-purple-300 font-mono">normalize-space()</code> or <code className="text-purple-300 font-mono">text()</code> for buttons, links, labels.
                </p>
                <div className="text-xs font-mono bg-slate-950/80 p-2 rounded text-purple-400">
                  //button[normalize-space()='Submit'] | //a[contains(text(),'Sign In')]
                </div>
              </div>

              <div className="p-3 rounded-lg bg-amber-950/30 border border-amber-800/40">
                <div className="flex items-center justify-between font-semibold text-amber-300 mb-1">
                  <span>4. Relational & Axis Navigation</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">Dynamic Tables / Forms</span>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  Anchor to a stable node (e.g. <code className="text-amber-300 font-mono">&lt;label&gt;</code> or <code className="text-amber-300 font-mono">&lt;td&gt;</code>) and traverse relative to it using axes (<code className="text-amber-300 font-mono">following-sibling::</code>, <code className="text-amber-300 font-mono">parent::</code>, <code className="text-amber-300 font-mono">ancestor::</code>).
                </p>
                <div className="text-xs font-mono bg-slate-950/80 p-2 rounded text-amber-400">
                  //label[normalize-space()='Email']/following-sibling::input[1]
                </div>
              </div>

              <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/40">
                <div className="flex items-center justify-between font-semibold text-rose-300 mb-1">
                  <span>5. Partial Matching</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-rose-500/20 text-rose-300">Semi-Dynamic IDs</span>
                </div>
                <p className="text-xs text-slate-400 mb-2">
                  Use <code className="text-rose-300 font-mono">contains()</code> or <code className="text-rose-300 font-mono">starts-with()</code> for semi-dynamic attributes.
                </p>
                <div className="text-xs font-mono bg-slate-950/80 p-2 rounded text-rose-400">
                  //button[contains(@id, 'btn-submit')]
                </div>
              </div>
            </div>
          </div>

          {/* Specialized Testing World Scenarios */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              Specialized Testing World Scenarios
            </h3>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="font-semibold text-cyan-300">SVG Icons & Namespace Trap:</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Standard <code className="text-rose-400 font-mono">//svg</code> fails in XML DOMs. Always use <code className="text-emerald-400 font-mono">//*[local-name()='svg']</code> or parent <code className="text-emerald-400 font-mono">//button[@aria-label='...']</code>.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="font-semibold text-cyan-300">Shadow DOM & Web Components:</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Playwright pierces open shadow roots automatically (<code className="text-indigo-300 font-mono">custom-element &gt;&gt; button</code>). Selenium requires JavascriptExecutor or <code className="text-indigo-300 font-mono">getShadowRoot()</code>.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="font-semibold text-cyan-300">Async Toasts & Alerts:</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Target accessibility hooks like <code className="text-emerald-400 font-mono">//*[@role='alert']</code> and <code className="text-emerald-400 font-mono">//*[@aria-live='assertive']</code> for transient toast lifecycle handling.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                <span className="font-semibold text-cyan-300">Payment Gateway iFrames:</span>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Isolate payment contexts via <code className="text-indigo-300 font-mono">page.frameLocator('#stripe-iframe')</code> or Selenium <code className="text-indigo-300 font-mono">driver.switchTo().frame(...)</code>.
                </p>
              </div>
            </div>
          </div>

          {/* Anti-Patterns */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-rose-400 mb-3 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              Forbidden Anti-Patterns
            </h3>
            <div className="p-4 rounded-lg bg-rose-950/20 border border-rose-800/40 space-y-2 text-xs">
              <div className="flex items-start gap-2 text-rose-300">
                <span className="font-bold text-rose-400">⛔ Absolute XPaths:</span>
                <span>NEVER generate selectors starting with <code className="bg-slate-950 px-1.5 py-0.5 rounded font-mono text-rose-400">/html/body/...</code>.</span>
              </div>
              <div className="flex items-start gap-2 text-rose-300">
                <span className="font-bold text-rose-400">⛔ Brittle Positional Indices:</span>
                <span>NEVER use arbitrary indices like <code className="bg-slate-950 px-1.5 py-0.5 rounded font-mono text-rose-400">(//div/span/input)[14]</code>.</span>
              </div>
              <div className="flex items-start gap-2 text-rose-300">
                <span className="font-bold text-rose-400">⛔ Framework Hash Classes:</span>
                <span>NEVER rely on auto-generated Tailwind/CSS-in-JS hashes like <code className="bg-slate-950 px-1.5 py-0.5 rounded font-mono text-rose-400">class="css-1a2b3c4"</code>.</span>
              </div>
            </div>
          </div>

          {/* Output Schema */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-indigo-400" />
              Raw JSON Contract
            </h3>
            <pre className="text-xs font-mono bg-slate-950 p-3 rounded-lg border border-slate-800 text-slate-300 overflow-x-auto">
{`{
  "target_functionality": "<brief description of requested element>",
  "best_xpath": "<the single highest-priority resilient XPath>",
  "strategy_used": "<e.g., QA Attribute / Text Normalized / Axis Traversal / Partial Match>",
  "alternative_xpaths": [
    "<backup XPath 1>",
    "<backup XPath 2>"
  ],
  "alternative_css_selector": "<equivalent CSS selector if possible, else null>",
  "playwright_semantic_locator": "<e.g., page.getByRole(...) or page.getByTestId(...)>",
  "confidence_score": "<0.0 to 1.0>",
  "explanation": "<1-2 sentence explanation of why this XPath was chosen over others>"
}`}
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow transition"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
