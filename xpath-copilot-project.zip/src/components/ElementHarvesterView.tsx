import React, { useState, useMemo } from 'react';
import { 
  Boxes, 
  Download, 
  Copy, 
  Check, 
  FileSpreadsheet, 
  Code, 
  Search, 
  Layers, 
  Play, 
  CheckCircle2, 
  AlertTriangle,
  FileCode2,
  Filter
} from 'lucide-react';
import { HarvestedElement, PomFormat } from '../types';
import { harvestAllInteractableElements, generatePageObjectModel, evaluateXPath } from '../utils/domEvaluator';

interface ElementHarvesterViewProps {
  html: string;
  onSelectElementToCopilot?: (snippet: string, description: string) => void;
}

export const ElementHarvesterView: React.FC<ElementHarvesterViewProps> = ({
  html,
  onSelectElementToCopilot,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPomFormat, setSelectedPomFormat] = useState<PomFormat>('playwright');
  const [pageClassName, setPageClassName] = useState<string>('Checkout');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [testResultModal, setTestResultModal] = useState<{ name: string; count: number; xpath: string } | null>(null);

  const harvestedElements = useMemo(() => {
    return harvestAllInteractableElements(html);
  }, [html]);

  const filteredElements = useMemo(() => {
    return harvestedElements.filter(el => {
      const matchesCategory = activeCategory === 'all' || el.category === activeCategory;
      const matchesSearch = 
        el.elementName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        el.bestXPath.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (el.testId && el.testId.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (el.elementText && el.elementText.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [harvestedElements, activeCategory, searchQuery]);

  const generatedPomCode = useMemo(() => {
    return generatePageObjectModel(harvestedElements, pageClassName, selectedPomFormat);
  }, [harvestedElements, pageClassName, selectedPomFormat]);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const downloadPom = () => {
    const extensions: Record<PomFormat, string> = {
      'playwright': 'ts',
      'selenium-java': 'java',
      'selenium-python': 'py',
      'cypress': 'js',
    };
    const ext = extensions[selectedPomFormat];
    const blob = new Blob([generatedPomCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pageClassName}Page.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportCsv = () => {
    const headers = ['Element Name', 'Category', 'Flakiness Grade', 'Best XPath', 'Playwright Locator', 'Cypress Locator', 'Test ID'];
    const rows = harvestedElements.map(el => [
      `"${el.elementName}"`,
      `"${el.category}"`,
      `"${el.flakinessGrade}"`,
      `"${el.bestXPath.replace(/"/g, '""')}"`,
      `"${el.playwrightLocator.replace(/"/g, '""')}"`,
      `"${el.cypressLocator.replace(/"/g, '""')}"`,
      `"${el.testId || ''}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pageClassName}_Locators_Inventory.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleTestInDom = (xpath: string, name: string) => {
    const res = evaluateXPath(html, xpath);
    setTestResultModal({
      name,
      count: res.matchCount,
      xpath,
    });
    setTimeout(() => setTestResultModal(null), 3000);
  };

  const getGradeBadge = (grade: HarvestedElement['flakinessGrade']) => {
    switch (grade) {
      case 'A+':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      case 'A':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'B':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      case 'C':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      default:
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Stats */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Boxes className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white">Full-Page Locator Harvester & POM Studio</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automatically extracts all interactable elements and generates production-ready Page Object Model files.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={exportCsv}
            disabled={harvestedElements.length === 0}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 disabled:opacity-40 transition border border-slate-700"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={downloadPom}
            disabled={harvestedElements.length === 0}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 shadow-md transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download POM</span>
          </button>
        </div>
      </div>

      {/* Floating Match Test Notification */}
      {testResultModal && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-slate-900 border border-indigo-500 shadow-2xl flex items-center space-x-3 animate-in slide-in-from-bottom duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <div className="text-xs">
            <p className="font-bold text-white">{testResultModal.name}</p>
            <p className="text-slate-400 font-mono text-[11px]">
              Found: <strong className={testResultModal.count === 1 ? 'text-emerald-400' : 'text-amber-400'}>{testResultModal.count} unique element(s)</strong> in DOM
            </p>
          </div>
        </div>
      )}

      {/* Two Column Layout: Elements Table & Live POM Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Element Inventory (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Discovered Elements ({filteredElements.length} of {harvestedElements.length})
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter elements..."
                className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-44"
              />
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {['all', 'button', 'input', 'select', 'checkbox', 'radio', 'link', 'custom'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium capitalize transition ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto max-h-[550px] overflow-y-auto border border-slate-800 rounded-xl bg-slate-950/60">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-950 sticky top-0 border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Identifier</th>
                  <th className="py-2.5 px-2">Type</th>
                  <th className="py-2.5 px-2">Risk</th>
                  <th className="py-2.5 px-3">Best XPath Locator</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredElements.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                      No matching elements found in the current HTML markup.
                    </td>
                  </tr>
                ) : (
                  filteredElements.map((el) => (
                    <tr key={el.id} className="hover:bg-slate-900/50 transition">
                      <td className="py-2.5 px-3 font-mono font-medium text-indigo-300">
                        {el.elementName}
                        {el.testId && (
                          <span className="block text-[10px] text-emerald-400 font-sans">
                            testid: {el.testId}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-2">
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          &lt;{el.tag}&gt;
                        </span>
                      </td>
                      <td className="py-2.5 px-2">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border ${getGradeBadge(el.flakinessGrade)}`}>
                          {el.flakinessGrade}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-300 max-w-[200px] truncate select-all">
                        {el.bestXPath}
                      </td>
                      <td className="py-2.5 px-3 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => handleTestInDom(el.bestXPath, el.elementName)}
                          className="px-2 py-1 text-[11px] rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          title="Evaluate in live DOM"
                        >
                          Test
                        </button>
                        <button
                          onClick={() => copyToClipboard(el.bestXPath, el.id)}
                          className="px-2 py-1 text-[11px] rounded bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white transition"
                          title="Copy XPath"
                        >
                          {copiedKey === el.id ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: POM Code Generator (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileCode2 className="w-4 h-4 text-indigo-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Page Object Model (POM)
              </h3>
            </div>
            <button
              onClick={() => copyToClipboard(generatedPomCode, 'full_pom')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              {copiedKey === 'full_pom' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey === 'full_pom' ? 'POM Copied!' : 'Copy POM'}</span>
            </button>
          </div>

          {/* POM Configuration Controls */}
          <div className="space-y-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between gap-2">
              <label className="text-[11px] text-slate-400 font-medium">Page Class Name:</label>
              <input
                type="text"
                value={pageClassName}
                onChange={(e) => setPageClassName(e.target.value)}
                placeholder="e.g., Checkout"
                className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded-md text-xs text-white font-mono w-36 text-right focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Framework Selector */}
            <div className="flex flex-wrap gap-1">
              <button
                onClick={() => setSelectedPomFormat('playwright')}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium transition ${
                  selectedPomFormat === 'playwright' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Playwright (TS)
              </button>
              <button
                onClick={() => setSelectedPomFormat('selenium-java')}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium transition ${
                  selectedPomFormat === 'selenium-java' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Selenium (Java)
              </button>
              <button
                onClick={() => setSelectedPomFormat('selenium-python')}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium transition ${
                  selectedPomFormat === 'selenium-python' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Selenium (Python)
              </button>
              <button
                onClick={() => setSelectedPomFormat('cypress')}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium transition ${
                  selectedPomFormat === 'cypress' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Cypress
              </button>
            </div>
          </div>

          {/* Code Area */}
          <div className="flex-1 min-h-[350px] relative">
            <pre className="absolute inset-0 p-3.5 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-300 overflow-auto leading-relaxed select-all">
              {generatedPomCode}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
