import React, { useMemo } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  Lightbulb, 
  ArrowUpRight, 
  Flame, 
  Shield, 
  Zap,
  Tag,
  Info
} from 'lucide-react';

interface ResilienceIndicatorProps {
  xpath: string;
  html?: string;
  onApplyRefactor?: (refactoredXPath: string) => void;
}

export interface ResilienceAnalysis {
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  score: number; // 0 - 100
  levelLabel: string;
  verdict: string;
  metrics: {
    attributeStability: { score: number; label: string; status: 'optimal' | 'moderate' | 'volatile' };
    layoutIndependence: { score: number; label: string; status: 'optimal' | 'moderate' | 'volatile' };
    whitespaceDefense: { score: number; label: string; status: 'optimal' | 'moderate' | 'volatile' };
  };
  detectedAttributes: {
    name: string;
    type: 'stable-testid' | 'persistent-attr' | 'semantic-text' | 'relational-axis' | 'volatile-class' | 'brittle-index' | 'absolute-path';
    impact: 'positive' | 'neutral' | 'negative';
    description: string;
  }[];
  tips: string[];
  suggestedRefactor?: string;
}

export function analyzeXPathResilience(xpath: string, html: string = ''): ResilienceAnalysis {
  if (!xpath || !xpath.trim()) {
    return {
      grade: 'F',
      score: 0,
      levelLabel: 'Empty Locator',
      verdict: 'No XPath expression provided.',
      metrics: {
        attributeStability: { score: 0, label: 'None', status: 'volatile' },
        layoutIndependence: { score: 0, label: 'None', status: 'volatile' },
        whitespaceDefense: { score: 0, label: 'None', status: 'volatile' },
      },
      detectedAttributes: [],
      tips: ['Enter or generate a valid XPath expression.'],
    };
  }

  let score = 70;
  const detectedAttributes: ResilienceAnalysis['detectedAttributes'] = [];
  const tips: string[] = [];
  let suggestedRefactor: string | undefined = undefined;

  // 1. Stable QA Attributes Check (Gold Standard)
  const hasTestId = /data-(?:testid|qa|cy|test)/i.test(xpath);
  if (hasTestId) {
    score += 30;
    detectedAttributes.push({
      name: 'Explicit QA Test Attribute',
      type: 'stable-testid',
      impact: 'positive',
      description: 'Uses data-testid, data-qa, or data-cy. Decoupled from UI design and translations.',
    });
  }

  // 2. Persistent Static ID or Name Check
  const hasId = /@id\s*=\s*['"]([^'"]+)['"]/i.exec(xpath);
  const hasName = /@name\s*=\s*['"]([^'"]+)['"]/i.exec(xpath);

  if (hasId) {
    const idVal = hasId[1];
    const isHash = /[0-9a-f]{6,}/i.test(idVal) || /^(css-|sc-|jsx-|react-)/i.test(idVal) || /_\d{4,}/.test(idVal);
    if (isHash) {
      score -= 25;
      detectedAttributes.push({
        name: `@id="${idVal}" (Dynamic Hash)`,
        type: 'volatile-class',
        impact: 'negative',
        description: 'Auto-generated or hashed ID changes on re-renders or new builds.',
      });
      tips.push('Avoid auto-generated IDs containing hashes. Use semantic attributes or request a static test ID.');
    } else {
      score += 15;
      detectedAttributes.push({
        name: `@id="${idVal}" (Static)`,
        type: 'persistent-attr',
        impact: 'positive',
        description: 'Static persistent identifier.',
      });
    }
  }

  if (hasName) {
    score += 12;
    detectedAttributes.push({
      name: `@name="${hasName[1]}"`,
      type: 'persistent-attr',
      impact: 'positive',
      description: 'Standard persistent form control name.',
    });
  }

  // 3. Volatile Class reliance Check
  const hasClass = /@class\s*=\s*['"]([^'"]+)['"]|contains\(@class,\s*['"]([^'"]+)['"]\)/i.exec(xpath);
  if (hasClass) {
    const classVal = hasClass[1] || hasClass[2];
    const isFrameworkHash = /(?:css-|sc-|jsx-|tailwind|[a-z0-9]{8,})/i.test(classVal);
    score -= isFrameworkHash ? 35 : 20;
    detectedAttributes.push({
      name: `Class attribute ("${classVal.slice(0, 20)}...")`,
      type: 'volatile-class',
      impact: 'negative',
      description: 'Classes frequently mutate during styling redesigns and CSS refactors.',
    });
    tips.push('Refactor away from CSS class names to eliminate breakage when styling changes.');
  }

  // 4. Absolute Path Check (Anti-Pattern)
  const isAbsolute = /^\/(?:html|body)/i.test(xpath.trim());
  if (isAbsolute) {
    score -= 45;
    detectedAttributes.push({
      name: 'Absolute Root Path (/html/body/...)',
      type: 'absolute-path',
      impact: 'negative',
      description: 'Tied directly to DOM tree hierarchy. Adding a wrapper div breaks the locator.',
    });
    tips.push('CRITICAL: Convert absolute XPath (/html/body/...) into a relative locator starting with //');
  }

  // 5. Positional Index Check
  const indexMatch = xpath.match(/\[(\d+)\]/g);
  if (indexMatch) {
    const highestIdx = Math.max(...indexMatch.map(m => parseInt(m.replace(/\D/g, ''), 10)));
    if (highestIdx > 2) {
      score -= 30;
      detectedAttributes.push({
        name: `High Positional Index [${highestIdx}]`,
        type: 'brittle-index',
        impact: 'negative',
        description: 'Hardcoded position index breaks whenever sibling elements are inserted or reordered.',
      });
      tips.push(`Replace index [${highestIdx}] with semantic text filtering (e.g. normalize-space()) or parent/ancestor axis traversal.`);
    }
  }

  // 6. Whitespace & Text Check
  if (xpath.includes('normalize-space(')) {
    score += 10;
    detectedAttributes.push({
      name: 'normalize-space() applied',
      type: 'semantic-text',
      impact: 'positive',
      description: 'Strips leading, trailing, and internal whitespace/newlines, preventing whitespace mismatches.',
    });
  } else if (xpath.includes('text()=')) {
    score -= 15;
    detectedAttributes.push({
      name: 'Exact text() match without normalize-space()',
      type: 'semantic-text',
      impact: 'negative',
      description: 'Breaks if HTML has formatting indentation, newlines, or extra spaces around text.',
    });
    tips.push('Wrap text filters inside normalize-space(), e.g. //button[normalize-space()="Submit"]');
  }

  // 7. Relational / Axis Traversal
  if (xpath.includes('following-sibling::') || xpath.includes('preceding-sibling::') || xpath.includes('ancestor::')) {
    score += 8;
    detectedAttributes.push({
      name: 'Relational Axis Navigation',
      type: 'relational-axis',
      impact: 'positive',
      description: 'Anchored relative to a stable semantic element (like label or table cell).',
    });
  }

  // 8. Suggest auto-refactor if test-id exists in HTML
  if (!hasTestId && html) {
    const testIdMatch = html.match(/data-(?:testid|qa|cy|test)=["']([^"']+)["']/i);
    if (testIdMatch) {
      suggestedRefactor = `//*[@data-testid='${testIdMatch[1]}']`;
      tips.push(`Frontend test hook found in markup! Consider switching to: //*[@data-testid='${testIdMatch[1]}']`);
    } else {
      tips.push('Dev Collaboration: Ask frontend engineers to add a data-testid attribute to guarantee permanent stability.');
    }
  }

  // Clamp Score
  score = Math.max(5, Math.min(100, score));

  // Determine Grade
  let grade: ResilienceAnalysis['grade'] = 'A+';
  let levelLabel = 'Rock Solid (Production Gold)';
  let verdict = 'Exceptional resilience. Immune to styling updates, layout changes, and localization.';

  if (score >= 95) {
    grade = 'A+';
    levelLabel = 'Rock Solid (Gold Standard)';
    verdict = 'Optimal stability. Utilizes dedicated QA test hooks with zero reliance on volatile markup.';
  } else if (score >= 85) {
    grade = 'A';
    levelLabel = 'High Resilience';
    verdict = 'Very stable. Relies on persistent unique attributes without brittle indices or volatile classes.';
  } else if (score >= 70) {
    grade = 'B';
    levelLabel = 'Moderate Resilience';
    verdict = 'Acceptable for test suites. Uses semantic text or axis anchors, but vulnerable if copy changes.';
  } else if (score >= 50) {
    grade = 'C';
    levelLabel = 'Flakiness Risk';
    verdict = 'Prone to intermittent test failures if DOM structure or component styles shift.';
  } else if (score >= 35) {
    grade = 'D';
    levelLabel = 'High Flakiness Risk';
    verdict = 'Brittle. Relies on layout positions or unstable styling attributes.';
  } else {
    grade = 'F';
    levelLabel = 'Broken / Anti-Pattern';
    verdict = 'Critically fragile. Uses forbidden absolute paths or arbitrary numeric indices.';
  }

  const attributeScore = hasTestId ? 100 : hasId || hasName ? 85 : hasClass ? 35 : 65;
  const layoutScore = isAbsolute ? 10 : indexMatch ? 40 : 95;
  const whitespaceScore = xpath.includes('normalize-space()') ? 100 : xpath.includes('text()=') ? 50 : 85;

  return {
    grade,
    score,
    levelLabel,
    verdict,
    metrics: {
      attributeStability: {
        score: attributeScore,
        label: hasTestId ? 'Dedicated QA Hook' : hasId || hasName ? 'Persistent Static Attribute' : hasClass ? 'Volatile Class Reliance' : 'Functional Attribute',
        status: attributeScore >= 80 ? 'optimal' : attributeScore >= 50 ? 'moderate' : 'volatile',
      },
      layoutIndependence: {
        score: layoutScore,
        label: isAbsolute ? 'Root Coupled (/html)' : indexMatch ? 'Positional Dependency' : 'Independent of Tree Depth',
        status: layoutScore >= 80 ? 'optimal' : layoutScore >= 50 ? 'moderate' : 'volatile',
      },
      whitespaceDefense: {
        score: whitespaceScore,
        label: xpath.includes('normalize-space()') ? 'Space Normalized' : xpath.includes('text()=') ? 'Unnormalized Whitespace' : 'Attribute Independent',
        status: whitespaceScore >= 80 ? 'optimal' : whitespaceScore >= 50 ? 'moderate' : 'volatile',
      },
    },
    detectedAttributes,
    tips,
    suggestedRefactor,
  };
}

export const ResilienceIndicator: React.FC<ResilienceIndicatorProps> = ({
  xpath,
  html = '',
  onApplyRefactor,
}) => {
  const analysis = useMemo(() => {
    return analyzeXPathResilience(xpath, html);
  }, [xpath, html]);

  const getGradeTheme = (grade: ResilienceAnalysis['grade']) => {
    switch (grade) {
      case 'A+':
        return {
          badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-emerald-500/20',
          meter: 'from-emerald-500 to-teal-400',
          text: 'text-emerald-400',
          glow: 'shadow-emerald-500/10 border-emerald-500/30',
        };
      case 'A':
        return {
          badge: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 shadow-emerald-500/10',
          meter: 'from-emerald-500 to-teal-400',
          text: 'text-emerald-400',
          glow: 'shadow-emerald-500/10 border-emerald-500/30',
        };
      case 'B':
        return {
          badge: 'bg-blue-500/15 text-blue-400 border-blue-500/30 shadow-blue-500/10',
          meter: 'from-blue-500 to-indigo-400',
          text: 'text-blue-400',
          glow: 'shadow-blue-500/10 border-blue-500/30',
        };
      case 'C':
        return {
          badge: 'bg-amber-500/15 text-amber-400 border-amber-500/30 shadow-amber-500/10',
          meter: 'from-amber-500 to-yellow-400',
          text: 'text-amber-400',
          glow: 'shadow-amber-500/10 border-amber-500/30',
        };
      case 'D':
        return {
          badge: 'bg-orange-500/15 text-orange-400 border-orange-500/30 shadow-orange-500/10',
          meter: 'from-orange-500 to-amber-500',
          text: 'text-orange-400',
          glow: 'shadow-orange-500/10 border-orange-500/30',
        };
      default:
        return {
          badge: 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-rose-500/20',
          meter: 'from-rose-600 to-red-500',
          text: 'text-rose-400',
          glow: 'shadow-rose-500/10 border-rose-500/30',
        };
    }
  };

  const theme = getGradeTheme(analysis.grade);

  return (
    <div className={`bg-slate-900/90 border rounded-2xl p-5 shadow-xl space-y-4 transition-all duration-300 ${theme.glow}`}>
      {/* Header with Title and Big Grade Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center border border-slate-700/80 shadow-inner">
            <Shield className={`w-5 h-5 ${theme.text}`} />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold text-white tracking-tight">
                Resilience Indicator
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-semibold">
                QA Stability Engine
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Evaluates reliance on volatile attributes vs stable test IDs
            </p>
          </div>
        </div>

        {/* Grade Badge Hero */}
        <div className="flex items-center space-x-3 self-start sm:self-auto">
          <div className="text-right">
            <span className="text-[11px] uppercase font-bold text-slate-400 block tracking-wider">
              Resilience Score
            </span>
            <span className="text-xs font-semibold text-slate-200">
              {analysis.score}/100 • <span className={theme.text}>{analysis.levelLabel}</span>
            </span>
          </div>

          <div className={`w-14 h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-lg transition-transform hover:scale-105 ${theme.badge}`}>
            <span className="text-2xl font-black font-mono leading-none tracking-tight">
              {analysis.grade}
            </span>
            <span className="text-[9px] font-bold uppercase tracking-wider mt-0.5 opacity-80">
              GRADE
            </span>
          </div>
        </div>
      </div>

      {/* Stability Score Meter */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs font-medium text-slate-400">
          <span className="flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            Flakiness Risk: <strong>{100 - analysis.score}%</strong>
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Immunity Rating: <strong className={theme.text}>{analysis.score}%</strong>
          </span>
        </div>
        <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
          <div 
            className={`h-full bg-gradient-to-r ${theme.meter} transition-all duration-500 rounded-full`}
            style={{ width: `${Math.max(8, analysis.score)}%` }}
          />
        </div>
      </div>

      {/* 3 Pillar Stability Breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-semibold">Attribute Durability</span>
            <span className={`font-mono font-bold ${analysis.metrics.attributeStability.status === 'optimal' ? 'text-emerald-400' : analysis.metrics.attributeStability.status === 'moderate' ? 'text-blue-400' : 'text-rose-400'}`}>
              {analysis.metrics.attributeStability.score}%
            </span>
          </div>
          <span className="text-xs text-slate-200 block truncate" title={analysis.metrics.attributeStability.label}>
            {analysis.metrics.attributeStability.label}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-semibold">DOM Independence</span>
            <span className={`font-mono font-bold ${analysis.metrics.layoutIndependence.status === 'optimal' ? 'text-emerald-400' : analysis.metrics.layoutIndependence.status === 'moderate' ? 'text-amber-400' : 'text-rose-400'}`}>
              {analysis.metrics.layoutIndependence.score}%
            </span>
          </div>
          <span className="text-xs text-slate-200 block truncate" title={analysis.metrics.layoutIndependence.label}>
            {analysis.metrics.layoutIndependence.label}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-semibold">Text Normalization</span>
            <span className={`font-mono font-bold ${analysis.metrics.whitespaceDefense.status === 'optimal' ? 'text-emerald-400' : analysis.metrics.whitespaceDefense.status === 'moderate' ? 'text-blue-400' : 'text-rose-400'}`}>
              {analysis.metrics.whitespaceDefense.score}%
            </span>
          </div>
          <span className="text-xs text-slate-200 block truncate" title={analysis.metrics.whitespaceDefense.label}>
            {analysis.metrics.whitespaceDefense.label}
          </span>
        </div>
      </div>

      {/* Detected Attributes Spectrum */}
      {analysis.detectedAttributes.length > 0 && (
        <div className="space-y-1.5 pt-1">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Tag className="w-3.5 h-3.5 text-indigo-400" />
            <span>Attributes & Structural Patterns Detected:</span>
          </div>
          <div className="grid grid-cols-1 gap-1.5">
            {analysis.detectedAttributes.map((attr, idx) => (
              <div 
                key={idx}
                className={`p-2 rounded-lg border text-xs flex items-center justify-between ${
                  attr.impact === 'positive'
                    ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300'
                    : attr.impact === 'neutral'
                    ? 'bg-slate-950 border-slate-800 text-slate-300'
                    : 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                }`}
              >
                <div className="flex items-center space-x-2 truncate pr-2">
                  {attr.impact === 'positive' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  ) : attr.impact === 'neutral' ? (
                    <Info className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                  )}
                  <span className="font-mono font-semibold truncate">{attr.name}</span>
                </div>
                <span className="text-[11px] text-slate-400 flex-shrink-0 hidden sm:inline">
                  {attr.description}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actionable Tips to Improve Stability */}
      {analysis.tips.length > 0 && (
        <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1.5 text-amber-300 font-semibold text-[11px] uppercase tracking-wide">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>Architect Recommendations to Boost Stability:</span>
            </div>
            {analysis.grade === 'A+' && (
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800/40">
                ✓ Fully Optimized
              </span>
            )}
          </div>

          <ul className="space-y-1.5 text-slate-300 text-[11px]">
            {analysis.tips.map((tip, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span className="leading-relaxed">{tip}</span>
              </li>
            ))}
          </ul>

          {/* Quick-Fix Upgrade Suggestion */}
          {analysis.suggestedRefactor && onApplyRefactor && (
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
              <div className="text-[11px] text-slate-400 truncate">
                Upgrade to Grade A: <code className="text-emerald-300 font-mono select-all">{analysis.suggestedRefactor}</code>
              </div>
              <button
                onClick={() => onApplyRefactor(analysis.suggestedRefactor!)}
                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold flex items-center gap-1 flex-shrink-0 transition shadow-sm"
              >
                <span>Apply Grade A</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
