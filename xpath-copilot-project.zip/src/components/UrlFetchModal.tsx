import React, { useState } from 'react';
import { X, Globe, Download, AlertCircle, Sparkles, ExternalLink } from 'lucide-react';

interface UrlFetchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUrlFetched: (html: string, title?: string, url?: string) => void;
}

export const UrlFetchModal: React.FC<UrlFetchModalProps> = ({
  isOpen,
  onClose,
  onUrlFetched,
}) => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickSamples = [
    { label: 'Example Domain', url: 'https://example.com' },
    { label: 'Hacker News (Dynamic Table)', url: 'https://news.ycombinator.com' },
    { label: 'JSONPlaceholder Web', url: 'https://jsonplaceholder.typicode.com' },
  ];

  const handleFetch = async () => {
    if (!url.trim()) return;
    setIsLoading(true);
    setError(null);

    let cleanUrl = url.trim();
    if (!/^https?:\/\//i.test(cleanUrl)) {
      cleanUrl = `https://${cleanUrl}`;
    }

    try {
      const response = await fetch('/api/fetch-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: cleanUrl }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to fetch web page content.');
      }

      onUrlFetched(data.html, data.title, cleanUrl);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Unable to fetch the specified URL. Please check CORS or connectivity.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-2.5">
            <Globe className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-bold text-white">Live Web Page Inspector</h2>
              <p className="text-xs text-slate-400">Fetch live DOM from any web application or staging URL</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Target Web URL
            </label>
            <div className="relative">
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleFetch()}
                placeholder="https://yourapp.staging.com or https://example.com"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono shadow-inner"
              />
            </div>
          </div>

          {/* Quick Demo URLs */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-semibold text-slate-400 block">Quick Testing Sites:</span>
            <div className="flex flex-wrap gap-1.5">
              {quickSamples.map((sample, idx) => (
                <button
                  key={idx}
                  onClick={() => setUrl(sample.url)}
                  className="text-xs px-2.5 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition flex items-center gap-1"
                >
                  <span>{sample.label}</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-950/40 border border-rose-800/50 rounded-xl text-xs text-rose-300 flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">Proxied safely through server-side fetch</span>
          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleFetch}
              disabled={isLoading || !url.trim()}
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-semibold shadow-md transition flex items-center gap-1.5"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Fetching DOM...</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Fetch Web Page</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
