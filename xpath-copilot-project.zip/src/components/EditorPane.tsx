import React, { useState } from 'react';
import { 
  Code, 
  Eye, 
  Sparkles, 
  RotateCcw, 
  MousePointerClick, 
  FileCheck, 
  Play,
  Globe,
  Tag
} from 'lucide-react';
import { SCENARIO_PRESETS } from '../data/presets';
import { ScenarioPreset } from '../types';

interface EditorPaneProps {
  html: string;
  setHtml: (html: string) => void;
  targetFunctionality: string;
  setTargetFunctionality: (val: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
  activePresetId: string;
  onSelectPreset: (preset: ScenarioPreset) => void;
  onOpenUrlModal: () => void;
}

export const EditorPane: React.FC<EditorPaneProps> = ({
  html,
  setHtml,
  targetFunctionality,
  setTargetFunctionality,
  onGenerate,
  isLoading,
  activePresetId,
  onSelectPreset,
  onOpenUrlModal,
}) => {
  const [activeTab, setActiveTab] = useState<'html' | 'preview'>('html');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [inspectedElement, setInspectedElement] = useState<string | null>(null);

  const activePreset = SCENARIO_PRESETS.find(p => p.id === activePresetId) || SCENARIO_PRESETS[0];

  const filteredPresets = selectedCategory === 'all'
    ? SCENARIO_PRESETS
    : SCENARIO_PRESETS.filter(p => p.category === selectedCategory);

  // Handle interactive click in the visual preview
  const handlePreviewElementClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (!target || target === e.currentTarget) return;

    e.preventDefault();
    e.stopPropagation();

    const tag = target.tagName.toLowerCase();
    const testId = target.getAttribute('data-testid') || target.getAttribute('data-qa') || target.getAttribute('data-cy');
    const id = target.id;
    const name = target.getAttribute('name');
    const role = target.getAttribute('role');
    const ariaLabel = target.getAttribute('aria-label');
    const text = target.textContent?.trim().slice(0, 30);
    const placeholder = target.getAttribute('placeholder');

    let desc = `Find the <${tag}>`;
    if (testId) desc += ` with test ID "${testId}"`;
    else if (ariaLabel) desc += ` with aria-label "${ariaLabel}"`;
    else if (role) desc += ` with role="${role}" and text "${text}"`;
    else if (text && (tag === 'button' || tag === 'a' || tag === 'span')) desc += ` button "${text}"`;
    else if (name) desc += ` field named "${name}"`;
    else if (placeholder) desc += ` input with placeholder "${placeholder}"`;
    else if (id) desc += ` with ID "${id}"`;

    setInspectedElement(`<${tag}${id ? ` id="${id}"` : ''}${testId ? ` data-testid="${testId}"` : ''}>`);
    setTargetFunctionality(desc);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Pane Top Bar */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/60 space-y-3">
        {/* Preset Category Bar */}
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-indigo-400" />
              <span>Testing World Scenarios:</span>
            </label>
            <button
              onClick={onOpenUrlModal}
              className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 hover:underline"
            >
              <Globe className="w-3 h-3" />
              <span>Fetch Live URL</span>
            </button>
          </div>

          {/* Scenario Chips Carousel */}
          <div className="flex flex-wrap gap-1.5">
            {filteredPresets.map((preset) => {
              const isActive = preset.id === activePresetId;
              return (
                <button
                  key={preset.id}
                  onClick={() => onSelectPreset(preset)}
                  className={`text-xs px-2.5 py-1 rounded-md font-medium transition ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/50'
                  }`}
                  title={preset.description}
                >
                  {preset.title.split('&')[0].trim()}
                </button>
              );
            })}
          </div>

          {activePreset.scenarioNotes && (
            <div className="text-[11px] text-slate-400 bg-slate-950/80 p-2 rounded-lg border border-slate-800/80 flex items-center gap-1.5">
              <Tag className="w-3 h-3 text-indigo-400 flex-shrink-0" />
              <span>{activePreset.scenarioNotes}</span>
            </div>
          )}
        </div>

        {/* Editor vs Visual Preview Tabs */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('html')}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-semibold transition ${
                activeTab === 'html'
                  ? 'bg-slate-800 text-indigo-300 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>HTML Markup (DOM)</span>
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-semibold transition ${
                activeTab === 'preview'
                  ? 'bg-slate-800 text-indigo-300 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Interactive Element Inspector</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
              {html.length} chars
            </span>
            <button
              onClick={() => setHtml('')}
              className="text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1 px-2 py-1 rounded hover:bg-slate-800 transition"
              title="Clear HTML markup"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>
        </div>
      </div>

      {/* Editor / Preview Area */}
      <div className="flex-1 relative min-h-[300px] overflow-hidden flex flex-col">
        {activeTab === 'html' ? (
          <div className="relative flex-1 flex flex-col">
            <textarea
              value={html}
              onChange={(e) => setHtml(e.target.value)}
              placeholder="<!-- Paste any HTML snippet, DOM fragment, or fetched page source... -->"
              className="w-full flex-1 p-4 bg-slate-950 font-mono text-xs text-slate-200 leading-relaxed resize-none focus:outline-none focus:ring-1 focus:ring-indigo-500/50 border-0"
              spellCheck={false}
            />
          </div>
        ) : (
          <div className="flex-1 bg-slate-950 p-4 overflow-y-auto">
            <div className="mb-2 text-xs text-indigo-300 bg-indigo-950/40 border border-indigo-800/40 rounded-lg p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="flex items-center gap-1.5">
                <MousePointerClick className="w-4 h-4 text-indigo-400" />
                Hover and click any element below to inspect and auto-target it!
              </span>
              {inspectedElement && (
                <span className="font-mono text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                  Targeted: {inspectedElement}
                </span>
              )}
            </div>
            {/* Sandboxed visual render */}
            <div 
              onClick={handlePreviewElementClick}
              className="p-4 bg-white text-slate-900 rounded-xl shadow-inner min-h-[240px] select-none cursor-crosshair border border-slate-700/40 transition hover:ring-1 hover:ring-indigo-400"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          </div>
        )}
      </div>

      {/* Target Functionality / User Request Section */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/80 space-y-3">
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              Target Element / Automation Request
            </label>
            <span className="text-[11px] text-slate-500">Press Cmd/Ctrl + Enter</span>
          </div>
          <div className="relative">
            <input
              type="text"
              value={targetFunctionality}
              onChange={(e) => setTargetFunctionality(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                  onGenerate();
                }
              }}
              placeholder='e.g., "Find the submit button in the checkout form"'
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition pr-28 shadow-inner"
            />
            <button
              onClick={onGenerate}
              disabled={isLoading || !html.trim() || !targetFunctionality.trim()}
              className="absolute right-1.5 top-1.5 bottom-1.5 px-3.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Solving...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Generate</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Suggestion Chips */}
        {activePreset?.sampleQueries && (
          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500 flex items-center gap-1">
              <span>Sample Scenario Queries:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {activePreset.sampleQueries.map((query, i) => (
                <button
                  key={i}
                  onClick={() => setTargetFunctionality(query)}
                  className={`text-[11px] text-left px-2.5 py-1 rounded-md transition border ${
                    targetFunctionality === query
                      ? 'bg-indigo-950/70 text-indigo-300 border-indigo-700/80 font-medium'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  "{query}"
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
