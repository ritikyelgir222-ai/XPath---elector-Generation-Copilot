import { ScenarioPreset } from '../types';

export const SCENARIO_PRESETS: ScenarioPreset[] = [
  {
    id: 'checkout-form',
    title: 'E-Commerce Checkout & Payment',
    badge: 'Tier 1 & 2 QA TestIds',
    category: 'e-commerce',
    description: 'Shopping cart with test IDs, unlabelled card inputs, and primary submit action.',
    scenarioNotes: 'Tests priority hierarchy 1 & 2: data-testid and static IDs vs dynamic hashes.',
    html: `<div class="checkout-container max-w-xl mx-auto p-6 bg-white rounded-xl shadow-lg">
  <h2 class="text-2xl font-bold text-gray-900 mb-6">Payment & Shipping</h2>
  <form id="payment-form" action="/process-order" method="POST">
    <!-- Email Field -->
    <div class="mb-4">
      <label for="customer-email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
      <input 
        type="email" 
        id="customer-email" 
        name="email" 
        data-testid="checkout-email-input" 
        placeholder="you@example.com"
        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500" 
        required 
      />
    </div>

    <!-- Shipping Address -->
    <div class="grid grid-cols-2 gap-4 mb-4">
      <div>
        <label for="shipping-city" class="block text-sm font-medium text-gray-700 mb-1">City</label>
        <input 
          type="text" 
          id="shipping-city" 
          name="city" 
          placeholder="San Francisco"
          class="w-full px-3 py-2 border border-gray-300 rounded-md" 
        />
      </div>
      <div>
        <label for="shipping-zip" class="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
        <input 
          type="text" 
          id="shipping-zip" 
          name="postalCode" 
          data-testid="postal-code-input"
          class="w-full px-3 py-2 border border-gray-300 rounded-md" 
        />
      </div>
    </div>

    <!-- Payment Option -->
    <fieldset class="mb-6">
      <legend class="text-sm font-medium text-gray-700 mb-2">Payment Method</legend>
      <div class="space-y-2">
        <label class="flex items-center space-x-3 cursor-pointer">
          <input type="radio" name="paymentMethod" value="credit_card" data-qa="radio-card" checked class="h-4 w-4 text-indigo-600" />
          <span class="text-sm text-gray-700">Credit / Debit Card</span>
        </label>
        <label class="flex items-center space-x-3 cursor-pointer">
          <input type="radio" name="paymentMethod" value="paypal" data-qa="radio-paypal" class="h-4 w-4 text-indigo-600" />
          <span class="text-sm text-gray-700">PayPal Express</span>
        </label>
      </div>
    </fieldset>

    <!-- Submit CTA -->
    <div class="pt-4 border-t border-gray-200 flex justify-between items-center">
      <button type="button" class="text-sm text-gray-500 hover:text-gray-700">Return to cart</button>
      <button 
        type="submit" 
        data-testid="submit-order-button" 
        id="btn-place-order" 
        class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-6 py-2.5 rounded-lg shadow transition"
      >
        Complete Order & Pay $149.00
      </button>
    </div>
  </form>
</div>`,
    sampleQueries: [
      'Find the submit button in the checkout form',
      'Find the email input field in the payment form',
      'Find the postal code input field',
      'Find the PayPal payment method radio button',
      'Find the return to cart button',
    ],
  },
  {
    id: 'data-table',
    title: 'Dynamic Data Table & Row Actions',
    badge: 'Tier 4 Relational & Axes',
    category: 'table',
    description: 'Dynamic user grid with actions relative to row text (e.g. Delete John Doe).',
    scenarioNotes: 'Tests axis navigation (following-sibling, parent::tr, ancestor::table) preventing index brittleness.',
    html: `<div class="p-4 bg-slate-900 text-slate-100 rounded-lg shadow">
  <div class="flex justify-between items-center mb-4">
    <h3 class="text-lg font-semibold">User Directory</h3>
    <button data-testid="add-user-btn" class="bg-blue-600 text-white px-3 py-1.5 rounded text-sm">Add New User</button>
  </div>
  <table class="w-full text-left border-collapse" id="users-table">
    <thead>
      <tr class="border-b border-slate-700 text-slate-400 text-xs uppercase">
        <th class="py-2 px-3">Name</th>
        <th class="py-2 px-3">Role</th>
        <th class="py-2 px-3">Status</th>
        <th class="py-2 px-3 text-right">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-800 text-sm">
      <tr data-row-id="user-101">
        <td class="py-3 px-3 font-medium">Alice Smith</td>
        <td class="py-3 px-3">Senior Admin</td>
        <td class="py-3 px-3"><span class="px-2 py-0.5 text-xs bg-green-500/20 text-green-400 rounded">Active</span></td>
        <td class="py-3 px-3 text-right space-x-2">
          <button class="text-xs text-blue-400 hover:underline" title="Edit Alice Smith">Edit</button>
          <button class="text-xs text-red-400 hover:underline" title="Delete Alice Smith">Delete</button>
        </td>
      </tr>
      <tr data-row-id="user-102">
        <td class="py-3 px-3 font-medium">John Doe</td>
        <td class="py-3 px-3">Automation Engineer</td>
        <td class="py-3 px-3"><span class="px-2 py-0.5 text-xs bg-yellow-500/20 text-yellow-400 rounded">Pending</span></td>
        <td class="py-3 px-3 text-right space-x-2">
          <button class="text-xs text-blue-400 hover:underline" title="Edit John Doe">Edit</button>
          <button class="text-xs text-red-400 hover:underline" title="Delete John Doe" aria-label="Delete user John Doe">Delete</button>
        </td>
      </tr>
      <tr data-row-id="user-103">
        <td class="py-3 px-3 font-medium">Sarah Connor</td>
        <td class="py-3 px-3">Security Lead</td>
        <td class="py-3 px-3"><span class="px-2 py-0.5 text-xs bg-green-500/20 text-green-400 rounded">Active</span></td>
        <td class="py-3 px-3 text-right space-x-2">
          <button class="text-xs text-blue-400 hover:underline">Edit</button>
          <button class="text-xs text-red-400 hover:underline">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>
</div>`,
    sampleQueries: [
      'Find the delete button for John Doe in the table',
      'Find the status badge for user Sarah Connor',
      'Find the Edit action for user Alice Smith',
      'Find the Add New User button',
    ],
  },
  {
    id: 'svg-icons',
    title: 'SVG Icons & Namespace Trap',
    badge: 'SVG local-name() Handling',
    category: 'svg',
    description: 'Icon buttons and SVGs lacking text, where standard //svg fails due to XML namespace.',
    scenarioNotes: 'Classic QA trap: //svg fails in XML/XHTML DOMs. Solution: //*[local-name()="svg"] or aria-label.',
    html: `<div class="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-4 max-w-lg mx-auto">
  <div class="flex items-center justify-between pb-3 border-b border-slate-800">
    <h3 class="text-sm font-bold text-white">Media Player Controls</h3>
    <button aria-label="Settings configuration" class="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="3"></circle>
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
      </svg>
    </button>
  </div>
  
  <div class="flex items-center justify-center space-x-6 py-4">
    <!-- Skip Previous Icon -->
    <button title="Previous track" data-testid="btn-prev-track" class="text-slate-400 hover:text-white">
      <svg class="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
        <polygon points="19 20 9 12 19 4 19 20"></polygon>
        <line x1="5" y1="19" x2="5" y2="5"></line>
      </svg>
    </button>

    <!-- Play/Pause Primary Action -->
    <button aria-label="Play audio track" class="w-12 h-12 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg">
      <svg class="w-6 h-6 fill-current" viewBox="0 0 24 24">
        <polygon points="5 3 19 12 5 21 5 3"></polygon>
      </svg>
    </button>

    <!-- Skip Next Icon -->
    <button title="Next track" data-testid="btn-next-track" class="text-slate-400 hover:text-white">
      <svg class="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
        <polygon points="5 4 15 12 5 20 5 4"></polygon>
        <line x1="19" y1="5" x2="19" y2="19"></line>
      </svg>
    </button>
  </div>
</div>`,
    sampleQueries: [
      'Find the Play audio track button with SVG icon',
      'Find the Previous track button',
      'Find the Next track button',
      'Find the Settings configuration icon button',
    ],
  },
  {
    id: 'shadow-dom',
    title: 'Shadow DOM & Web Components',
    badge: 'Shadow Root Pierce Strategies',
    category: 'shadow-dom',
    description: 'Custom elements with open shadow roots requiring piercing locator syntax in Playwright and Selenium.',
    scenarioNotes: 'In Playwright, custom-datepicker >> button pierces shadow DOM automatically; in Selenium/Cypress, shadow() traversal is needed.',
    html: `<div class="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-4 max-w-md mx-auto">
  <h3 class="text-sm font-bold text-white mb-2">Flight Reservation Widget</h3>
  
  <!-- Web Component 1: Custom Datepicker -->
  <custom-datepicker id="departure-picker" data-testid="departure-datepicker">
    #shadow-root (open)
    <div class="calendar-wrapper p-3 bg-slate-800 rounded-lg">
      <label class="text-xs text-slate-400 block mb-1">Departure Date</label>
      <input type="text" class="datepicker-input px-3 py-1.5 text-sm bg-slate-900 border border-slate-700 rounded text-white" value="2026-11-15" />
      <button type="button" class="btn-calendar-toggle ml-2 px-2 py-1 bg-indigo-600 text-white rounded text-xs" aria-label="Open departure calendar">
        📅 Pick
      </button>
    </div>
  </custom-datepicker>

  <!-- Web Component 2: Passenger Count Counter -->
  <passenger-stepper id="passenger-selector" data-testid="passenger-count-stepper">
    #shadow-root (open)
    <div class="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
      <span class="text-sm text-slate-200">Adults (12+ yrs)</span>
      <div class="flex items-center space-x-2">
        <button class="step-down px-2 py-1 bg-slate-700 text-white rounded font-bold" aria-label="Decrease adult count">-</button>
        <span class="count-value font-mono px-2 text-white">2</span>
        <button class="step-up px-2 py-1 bg-slate-700 text-white rounded font-bold" aria-label="Increase adult count">+</button>
      </div>
    </div>
  </passenger-stepper>
</div>`,
    sampleQueries: [
      'Find the Open departure calendar button inside the custom datepicker',
      'Find the Increase adult count button in the passenger stepper',
      'Find the departure date input field',
    ],
  },
  {
    id: 'transient-toast',
    title: 'Async Toasts, Alerts & Loading Spinners',
    badge: 'ARIA Live & Role Alert',
    category: 'toast',
    description: 'Dynamic UI notifications that auto-dismiss or appear conditionally after async actions.',
    scenarioNotes: 'Tests role="alert" and aria-live="assertive" for reliable synchronization in test runners.',
    html: `<div class="relative p-6 bg-slate-900 border border-slate-800 rounded-xl max-w-md mx-auto min-h-[300px]">
  <h3 class="text-sm font-bold text-white mb-4">Background Sync Dashboard</h3>
  
  <button id="trigger-sync-btn" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow">
    Start Sync Process
  </button>

  <!-- Active Loading Overlay (Conditionally rendered) -->
  <div id="sync-loader" role="status" aria-live="polite" class="mt-4 p-3 bg-blue-950/40 border border-blue-800/40 rounded-lg flex items-center space-x-3">
    <div class="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
    <span class="text-xs text-blue-300">Synchronizing records with remote server...</span>
  </div>

  <!-- Toast Notification (Role Alert) -->
  <div 
    id="toast-notification-success" 
    role="alert" 
    aria-live="assertive" 
    data-testid="toast-success-banner"
    class="mt-4 p-3 bg-emerald-950/60 border border-emerald-800/60 rounded-xl flex items-start justify-between shadow-lg"
  >
    <div class="flex items-center space-x-2">
      <span class="text-emerald-400 font-bold">✓</span>
      <div>
        <p class="text-xs font-semibold text-emerald-200">Sync Completed Successfully</p>
        <p class="text-[11px] text-emerald-400/80">342 customer records updated in 1.4s.</p>
      </div>
    </div>
    <button aria-label="Close notification" class="text-emerald-400 hover:text-emerald-200 text-sm font-bold">×</button>
  </div>
</div>`,
    sampleQueries: [
      'Find the Sync Completed Successfully toast alert',
      'Find the Close notification button on the toast',
      'Find the Synchronizing records loader message',
      'Find the Start Sync Process button',
    ],
  },
  {
    id: 'combobox-autocomplete',
    title: 'Combobox, Select & Autocomplete Dropdown',
    badge: 'ARIA Role Combobox',
    category: 'combobox',
    description: 'Custom React-Select / Headless UI comboboxes with clear buttons and active option list.',
    scenarioNotes: 'Tests role="combobox", aria-expanded, and role="option" selection strategies.',
    html: `<div class="p-6 bg-slate-900 border border-slate-800 rounded-xl max-w-md mx-auto space-y-4">
  <label id="country-select-label" class="block text-xs font-semibold uppercase tracking-wider text-slate-400">
    Select Country of Residence
  </label>
  
  <div class="relative">
    <!-- Combobox Input Container -->
    <div 
      role="combobox" 
      aria-expanded="true" 
      aria-haspopup="listbox" 
      aria-labelledby="country-select-label"
      data-testid="country-combobox-wrapper"
      class="flex items-center justify-between px-3 py-2 bg-slate-950 border border-indigo-500 rounded-lg text-sm text-white"
    >
      <input 
        type="text" 
        id="country-search-input" 
        placeholder="Search countries..." 
        value="United"
        class="bg-transparent border-0 focus:outline-none text-white text-sm w-full"
      />
      <button type="button" aria-label="Clear selected country" class="text-slate-400 hover:text-white px-1">✕</button>
    </div>

    <!-- Active Popup Options Listbox -->
    <ul 
      role="listbox" 
      id="country-options-list" 
      aria-label="Available countries"
      class="absolute left-0 right-0 mt-1 bg-slate-950 border border-slate-700 rounded-lg shadow-xl overflow-hidden z-20 text-xs"
    >
      <li role="option" aria-selected="true" class="px-3 py-2 bg-indigo-600/30 text-indigo-200 cursor-pointer flex justify-between">
        <span>United States</span>
        <span class="text-indigo-400 font-mono">US</span>
      </li>
      <li role="option" aria-selected="false" class="px-3 py-2 text-slate-300 hover:bg-slate-800 cursor-pointer flex justify-between">
        <span>United Kingdom</span>
        <span class="text-slate-500 font-mono">GB</span>
      </li>
      <li role="option" aria-selected="false" class="px-3 py-2 text-slate-300 hover:bg-slate-800 cursor-pointer flex justify-between">
        <span>United Arab Emirates</span>
        <span class="text-slate-500 font-mono">AE</span>
      </li>
    </ul>
  </div>
</div>`,
    sampleQueries: [
      'Find the United States option in the country listbox',
      'Find the Clear selected country button in the combobox',
      'Find the country search input field',
      'Find the United Kingdom option',
    ],
  },
  {
    id: 'iframe-context',
    title: 'Embedded iFrames & Payment Gateway',
    badge: 'Context Switch & Frame Locators',
    category: 'iframe',
    description: 'Embedded payment iframes (like Stripe Elements / PayPal) that require frame switching.',
    scenarioNotes: 'Tests frameLocator() in Playwright, switchTo().frame() in Selenium, and its() in Cypress.',
    html: `<div class="p-6 bg-slate-900 border border-slate-800 rounded-xl max-w-lg mx-auto space-y-4">
  <h3 class="text-base font-bold text-white">Stripe Payment Gateway Integration</h3>
  <p class="text-xs text-slate-400">Card details are hosted in an isolated secure sandbox iframe.</p>

  <!-- Embedded Stripe Card Iframe Container -->
  <div class="stripe-card-field-container border border-slate-700 rounded-lg p-3 bg-slate-950">
    <iframe 
      id="stripe-card-element-iframe" 
      name="__privateStripeFrame101" 
      title="Secure payment input frame"
      data-testid="stripe-iframe"
      src="https://js.stripe.com/v3/elements-inner-card.html"
      class="w-full h-10 border-0"
    >
      <!-- Inside iframe context: -->
      <html>
        <body>
          <input id="card-number" name="cardnumber" placeholder="1234 5678 9012 3456" data-elements-stable-field-name="cardNumber" />
          <input id="card-expiry" name="exp-date" placeholder="MM / YY" />
          <input id="card-cvc" name="cvc" placeholder="CVC" />
        </body>
      </html>
    </iframe>
  </div>

  <button 
    id="btn-pay-securely" 
    data-testid="pay-now-btn"
    class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-sm transition"
  >
    Pay $79.00 with Encrypted Token
  </button>
</div>`,
    sampleQueries: [
      'Find the Stripe payment iframe element',
      'Find the card number input inside the payment iframe',
      'Find the Pay with Encrypted Token button',
      'Find the card expiration date input inside iframe',
    ],
  },
  {
    id: 'unlabeled-form',
    title: 'Unlabelled Form & Floating Labels',
    badge: 'Tier 3 & 4 Axis Navigation',
    category: 'forms',
    description: 'Inputs with no ID or testid, requiring traversal from preceding label text with normalize-space().',
    scenarioNotes: 'Tests following-sibling axis from label to input when developer forgot id/name.',
    html: `<div class="max-w-md mx-auto p-6 bg-slate-50 border border-slate-200 rounded-lg text-slate-900">
  <h3 class="text-xl font-bold text-slate-800 mb-4">Account Security Verification</h3>
  <form class="space-y-4">
    <div class="form-group">
      <label class="block text-sm font-semibold text-slate-700 mb-1">
        Corporate Work Email
      </label>
      <input 
        type="text" 
        class="w-full px-3 py-2 border border-slate-300 rounded shadow-sm text-slate-800"
        placeholder="username@company.corp" 
      />
      <small class="text-xs text-slate-500">Must end in @company.corp</small>
    </div>

    <div class="form-group">
      <label class="block text-sm font-semibold text-slate-700 mb-1">
        Emergency Security PIN
      </label>
      <input 
        type="password" 
        maxlength="6" 
        class="w-full px-3 py-2 border border-slate-300 rounded shadow-sm text-center tracking-widest text-slate-800"
        placeholder="••••••" 
      />
    </div>

    <div class="flex items-center space-x-2 pt-2">
      <input type="checkbox" class="h-4 w-4 rounded border-gray-300 text-indigo-600" />
      <span class="text-sm text-slate-600">I confirm this is my dedicated enterprise device</span>
    </div>

    <div class="pt-4">
      <button type="submit" class="w-full py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded">
        Verify Identity
      </button>
    </div>
  </form>
</div>`,
    sampleQueries: [
      'Find the email input field next to the Corporate Work Email label',
      'Find the Emergency Security PIN password input',
      'Find the dedicated enterprise device confirmation checkbox',
      'Find the Verify Identity submit button',
    ],
  },
];
