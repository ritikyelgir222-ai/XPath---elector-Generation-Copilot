import { 
  EvaluationResult, 
  MatchedElementSummary, 
  HarvestedElement, 
  FlakinessAudit, 
  PomFormat 
} from '../types';

/**
 * Validates and evaluates an XPath expression against an HTML string within a sandboxed DOM.
 */
export function evaluateXPath(html: string, xpath: string): EvaluationResult {
  if (!xpath || !xpath.trim()) {
    return {
      isValidXPath: false,
      matchCount: 0,
      matchedElements: [],
      error: 'XPath expression cannot be empty.',
      antiPatternWarnings: [],
    };
  }

  const antiPatternWarnings: string[] = [];

  // Check 1: Absolute XPath
  if (/^\/(?:html|body)/i.test(xpath.trim())) {
    antiPatternWarnings.push('Anti-Pattern Detected: Absolute XPath starting with /html/body/... is fragile to layout changes.');
  }

  // Check 2: Brittle positional index (> 3)
  const highIndexMatch = xpath.match(/\[(\d+)\]/);
  if (highIndexMatch && parseInt(highIndexMatch[1], 10) > 3) {
    antiPatternWarnings.push(`Anti-Pattern Detected: High positional index [${highIndexMatch[1]}]. Indices break easily when sibling elements change.`);
  }

  // Check 3: Tailwind/CSS-in-JS hashes in class matching
  if (/class=['"][^'"]*(css-[a-z0-9]+|sc-[a-z0-9]+|[a-z0-9]{8,})['"]/i.test(xpath)) {
    antiPatternWarnings.push('Anti-Pattern Warning: Appears to rely on generated framework classes or hashes.');
  }

  // Check 4: SVG tag trap (//svg vs //*[local-name()='svg'])
  if (/\/\/svg\b/i.test(xpath)) {
    antiPatternWarnings.push('SVG Namespace Trap: Direct "//svg" often fails in XML/XHTML namespaces. Use "//*[local-name()=\'svg\']" instead.');
  }

  // Check 5: Missing normalize-space on text()
  if (/text\(\)\s*=\s*['"]/i.test(xpath) && !xpath.includes('normalize-space()')) {
    antiPatternWarnings.push('Recommendation: Consider using normalize-space() instead of direct text() to avoid whitespace failures.');
  }

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Run XPath evaluation on the parsed document
    const result = doc.evaluate(
      xpath,
      doc,
      null,
      XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
      null
    );

    const matchCount = result.snapshotLength;
    const matchedElements: MatchedElementSummary[] = [];

    for (let i = 0; i < Math.min(matchCount, 10); i++) {
      const node = result.snapshotItem(i);
      if (node && node.nodeType === Node.ELEMENT_NODE) {
        const el = node as Element;
        const outerHTML = el.outerHTML;
        const truncatedSnippet = outerHTML.length > 200 
          ? outerHTML.slice(0, 197) + '...' 
          : outerHTML;

        matchedElements.push({
          index: i + 1,
          tagName: el.tagName.toLowerCase(),
          id: el.id || undefined,
          name: el.getAttribute('name') || undefined,
          testId: el.getAttribute('data-testid') || el.getAttribute('data-qa') || el.getAttribute('data-cy') || undefined,
          textContent: el.textContent?.trim().slice(0, 80) || undefined,
          outerHTMLSnippet: truncatedSnippet,
        });
      } else if (node) {
        matchedElements.push({
          index: i + 1,
          tagName: node.nodeName.toLowerCase(),
          textContent: node.textContent?.trim().slice(0, 80) || undefined,
          outerHTMLSnippet: node.textContent?.slice(0, 100) || '',
        });
      }
    }

    let strategyRating: 'gold' | 'silver' | 'bronze' | 'warning' = 'silver';
    if (xpath.includes('data-testid') || xpath.includes('data-qa') || xpath.includes('data-cy') || xpath.includes('data-test')) {
      strategyRating = 'gold';
    } else if (antiPatternWarnings.length > 0) {
      strategyRating = 'warning';
    } else if (xpath.includes('@id=') || xpath.includes('@name=')) {
      strategyRating = 'silver';
    } else {
      strategyRating = 'bronze';
    }

    return {
      isValidXPath: true,
      matchCount,
      matchedElements,
      strategyRating,
      antiPatternWarnings,
    };
  } catch (err: any) {
    return {
      isValidXPath: false,
      matchCount: 0,
      matchedElements: [],
      error: err.message || 'Invalid XPath expression syntax.',
      antiPatternWarnings,
    };
  }
}

/**
 * Calculates a comprehensive Flakiness Audit for a locator.
 */
export function calculateFlakinessAudit(xpath: string, _html: string): FlakinessAudit {
  let score = 100;
  const checks: FlakinessAudit['checks'] = [];
  const recommendations: string[] = [];

  // Check 1: Absolute Path check
  if (/^\/(?:html|body)/i.test(xpath.trim())) {
    score -= 40;
    checks.push({
      name: 'Relative vs Absolute Path',
      status: 'fail',
      detail: 'Uses forbidden absolute path starting from root (/html/body). Any DOM restructuring will break this test.',
    });
    recommendations.push('Refactor into a relative XPath targeting unique anchor attributes.');
  } else {
    checks.push({
      name: 'Relative vs Absolute Path',
      status: 'pass',
      detail: 'Proper relative locator starting with // or specific tag.',
    });
  }

  // Check 2: QA Test Attribute
  if (xpath.includes('data-testid') || xpath.includes('data-qa') || xpath.includes('data-cy') || xpath.includes('data-test')) {
    checks.push({
      name: 'QA Test Attribute Attachment',
      status: 'pass',
      detail: 'Leverages Gold Standard test attributes (data-testid/data-qa/data-cy), immune to styling and text translations.',
    });
  } else {
    score -= 10;
    checks.push({
      name: 'QA Test Attribute Attachment',
      status: 'warn',
      detail: 'No dedicated test attributes detected. Relies on layout, text, or functional attributes.',
    });
    recommendations.push('Consider requesting front-end engineering to add a dedicated data-testid attribute.');
  }

  // Check 3: Positional Indices
  const indexMatch = xpath.match(/\[(\d+)\]/);
  if (indexMatch && parseInt(indexMatch[1], 10) > 2) {
    score -= 25;
    checks.push({
      name: 'Positional Index Brittleness',
      status: 'fail',
      detail: `Contains positional index [${indexMatch[1]}]. If dynamic content shifts elements, this selector will target the wrong element.`,
    });
    recommendations.push('Replace positional index with semantic filtering, text matching, or relational axis navigation.');
  } else {
    checks.push({
      name: 'Positional Index Brittleness',
      status: 'pass',
      detail: 'Free of brittle high positional indices.',
    });
  }

  // Check 4: CSS-in-JS or generated hashes
  if (/class=['"][^'"]*(css-[a-z0-9]+|sc-[a-z0-9]+|[a-z0-9]{8,})['"]/i.test(xpath)) {
    score -= 30;
    checks.push({
      name: 'CSS Class Hash Durability',
      status: 'fail',
      detail: 'References volatile CSS-in-JS or framework-generated hash classes which change on every build.',
    });
    recommendations.push('Remove class name hash filters and use semantic attributes or text content.');
  } else {
    checks.push({
      name: 'CSS Class Hash Durability',
      status: 'pass',
      detail: 'No volatile CSS class hashes detected.',
    });
  }

  // Check 5: Space Normalization on Text
  if (xpath.includes('text()=') && !xpath.includes('normalize-space()')) {
    score -= 15;
    checks.push({
      name: 'Whitespace Normalization',
      status: 'warn',
      detail: 'Exact text() match without normalize-space() can break if whitespace, newlines, or tabs exist in HTML.',
    });
    recommendations.push('Wrap text filters inside normalize-space() for whitespace resilience.');
  } else if (xpath.includes('normalize-space()')) {
    checks.push({
      name: 'Whitespace Normalization',
      status: 'pass',
      detail: 'Properly normalizes inner text whitespace using normalize-space().',
    });
  } else {
    checks.push({
      name: 'Whitespace Normalization',
      status: 'pass',
      detail: 'Not dependent on unnormalized text strings.',
    });
  }

  // Grade calculation
  let grade: FlakinessAudit['grade'] = 'A+';
  if (score >= 95) grade = 'A+';
  else if (score >= 85) grade = 'A';
  else if (score >= 70) grade = 'B';
  else if (score >= 50) grade = 'C';
  else if (score >= 35) grade = 'D';
  else grade = 'F';

  return {
    grade,
    score: Math.max(0, Math.min(100, score)),
    checks,
    recommendations,
  };
}

/**
 * Validates a CSS selector against the parsed HTML snippet.
 */
export function evaluateCssSelector(html: string, selector: string | null): { isValid: boolean; count: number; error?: string } {
  if (!selector || !selector.trim()) {
    return { isValid: false, count: 0 };
  }

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const nodes = doc.querySelectorAll(selector);
    return {
      isValid: true,
      count: nodes.length,
    };
  } catch (err: any) {
    return {
      isValid: false,
      count: 0,
      error: err.message,
    };
  }
}

/**
 * Scans the entire HTML snippet and harvests all interactable elements into structured records.
 */
export function harvestAllInteractableElements(html: string): HarvestedElement[] {
  const elements: HarvestedElement[] = [];
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const nodes = doc.querySelectorAll(
      'button, input, select, textarea, a[href], [role="button"], [role="combobox"], [role="checkbox"], [role="radio"], [role="alert"], [data-testid], custom-datepicker, passenger-stepper'
    );

    const usedNames = new Set<string>();

    nodes.forEach((node, index) => {
      const el = node as HTMLElement;
      const tag = el.tagName.toLowerCase();
      const testId = el.getAttribute('data-testid') || el.getAttribute('data-qa') || el.getAttribute('data-cy') || undefined;
      const id = el.id && !(/[0-9a-f]{6,}/i.test(el.id) || /^(css-|sc-|jsx-)/i.test(el.id)) ? el.id : undefined;
      const name = el.getAttribute('name') || undefined;
      const type = el.getAttribute('type') || '';
      const text = el.textContent?.trim().slice(0, 40) || '';
      const ariaLabel = el.getAttribute('aria-label') || undefined;
      const placeholder = el.getAttribute('placeholder') || undefined;

      // Determine Category
      let category: HarvestedElement['category'] = 'other';
      if (tag === 'button' || el.getAttribute('role') === 'button' || type === 'submit' || type === 'button') category = 'button';
      else if (type === 'checkbox' || el.getAttribute('role') === 'checkbox') category = 'checkbox';
      else if (type === 'radio' || el.getAttribute('role') === 'radio') category = 'radio';
      else if (tag === 'select' || el.getAttribute('role') === 'combobox') category = 'select';
      else if (tag === 'input' || tag === 'textarea') category = 'input';
      else if (tag === 'a') category = 'link';
      else if (tag.startsWith('custom-') || tag.includes('-')) category = 'custom';

      // Generate Clean camelCase Element Identifier for POM
      let rawName = testId || id || name || ariaLabel || placeholder || text || `${category}_${index + 1}`;
      rawName = rawName.replace(/[^a-zA-Z0-9]/g, ' ').trim();
      const parts = rawName.split(/\s+/).filter(Boolean);
      let elementName = parts.length > 0 
        ? parts[0].toLowerCase() + parts.slice(1).map(p => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase()).join('')
        : `element${index + 1}`;
      
      // Ensure element name ends with type suffix if helpful
      if (category === 'button' && !elementName.toLowerCase().endsWith('btn') && !elementName.toLowerCase().endsWith('button')) {
        elementName += 'Button';
      } else if (category === 'input' && !elementName.toLowerCase().endsWith('input') && !elementName.toLowerCase().endsWith('field')) {
        elementName += 'Input';
      }

      // Deduplicate
      let finalName = elementName;
      let counter = 1;
      while (usedNames.has(finalName)) {
        finalName = `${elementName}${counter++}`;
      }
      usedNames.add(finalName);

      // Construct Best XPath following priority rules
      let bestXPath = '';
      let flakinessGrade: HarvestedElement['flakinessGrade'] = 'B';
      let cssSelector = '';
      let playwrightLocator = '';

      if (testId) {
        bestXPath = `//*[@data-testid='${testId}']`;
        cssSelector = `[data-testid="${testId}"]`;
        playwrightLocator = `page.getByTestId('${testId}')`;
        flakinessGrade = 'A+';
      } else if (id) {
        bestXPath = `//${tag}[@id='${id}']`;
        cssSelector = `#${id}`;
        playwrightLocator = `page.locator('#${id}')`;
        flakinessGrade = 'A';
      } else if (name) {
        bestXPath = `//${tag}[@name='${name}']`;
        cssSelector = `${tag}[name="${name}"]`;
        playwrightLocator = `page.locator('${tag}[name="${name}"]')`;
        flakinessGrade = 'A';
      } else if (ariaLabel) {
        bestXPath = `//${tag}[@aria-label='${ariaLabel}']`;
        cssSelector = `${tag}[aria-label="${ariaLabel}"]`;
        playwrightLocator = `page.getByLabel('${ariaLabel}')`;
        flakinessGrade = 'A';
      } else if (text && text.length > 2 && (tag === 'button' || tag === 'a' || tag === 'span')) {
        bestXPath = `//${tag}[normalize-space()='${text}']`;
        cssSelector = `${tag}`;
        playwrightLocator = tag === 'button' 
          ? `page.getByRole('button', { name: '${text}' })`
          : `page.getByRole('link', { name: '${text}' })`;
        flakinessGrade = 'B';
      } else if (placeholder) {
        bestXPath = `//${tag}[@placeholder='${placeholder}']`;
        cssSelector = `${tag}[placeholder="${placeholder}"]`;
        playwrightLocator = `page.getByPlaceholder('${placeholder}')`;
        flakinessGrade = 'B';
      } else {
        bestXPath = `(//${tag})[${index + 1}]`;
        cssSelector = `${tag}:nth-of-type(${index + 1})`;
        playwrightLocator = `page.locator('${tag}').nth(${index})`;
        flakinessGrade = 'D';
      }

      const cleanXpath = bestXPath.replace(/'/g, "\\'");
      const seleniumJava = `driver.findElement(By.xpath("${cleanXpath}"));`;
      const seleniumPython = `driver.find_element(By.XPATH, "${cleanXpath}")`;
      const cypressLocator = cssSelector && !cssSelector.includes(':nth-of-type') 
        ? `cy.get('${cssSelector}')` 
        : `cy.xpath('${cleanXpath}')`;

      elements.push({
        id: `el-${index + 1}`,
        elementName: finalName,
        tag,
        category,
        bestXPath,
        cssSelector,
        playwrightLocator,
        cypressLocator,
        seleniumJava,
        seleniumPython,
        flakinessGrade,
        testId,
        elementText: text || undefined,
        htmlSnippet: el.outerHTML.slice(0, 160) + (el.outerHTML.length > 160 ? '...' : ''),
      });
    });
  } catch (err) {
    console.error('Error harvesting elements:', err);
  }

  return elements;
}

/**
 * Generates an end-to-end Page Object Model (POM) source code file for test suites.
 */
export function generatePageObjectModel(elements: HarvestedElement[], pageName: string, format: PomFormat): string {
  const cleanClassName = (pageName.replace(/[^a-zA-Z0-9]/g, '') || 'Application') + 'Page';

  if (format === 'playwright') {
    const locatorsDef = elements
      .map(el => `  readonly ${el.elementName}: Locator;`)
      .join('\n');

    const locatorsInit = elements
      .map(el => `    this.${el.elementName} = ${el.playwrightLocator};`)
      .join('\n');

    return `import { expect, type Locator, type Page } from '@playwright/test';

/**
 * ${cleanClassName}
 * Generated automatically by XPath & Selector Generation Copilot
 */
export class ${cleanClassName} {
  readonly page: Page;

  // Web Locators
${locatorsDef}

  constructor(page: Page) {
    this.page = page;
${locatorsInit}
  }

  async verifyPageLoaded(): Promise<void> {
    await this.page.waitForLoadState('domcontentloaded');
  }
}
`;
  }

  if (format === 'selenium-java') {
    const fields = elements
      .map(el => `    @FindBy(xpath = "${el.bestXPath.replace(/"/g, '\\"')}")
    private WebElement ${el.elementName};`)
      .join('\n\n');

    const getters = elements
      .map(el => `    public WebElement get${el.elementName.charAt(0).toUpperCase() + el.elementName.slice(1)}() {
        return ${el.elementName};
    }`)
      .join('\n\n');

    return `package com.automation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * ${cleanClassName} (Selenium WebDriver Java PageFactory)
 * Generated automatically by XPath & Selector Generation Copilot
 */
public class ${cleanClassName} {

    private final WebDriver driver;

    // Page Elements
${fields}

    public ${cleanClassName}(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Getters
${getters}
}
`;
  }

  if (format === 'selenium-python') {
    const locators = elements
      .map(el => `    ${el.elementName.toUpperCase()}_LOCATOR = (By.XPATH, "${el.bestXPath.replace(/"/g, '\\"')}")`)
      .join('\n');

    const methods = elements
      .map(el => `    def get_${el.elementName}(self):
        return self.driver.find_element(*self.${el.elementName.toUpperCase()}_LOCATOR)`)
      .join('\n\n');

    return `from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver

class ${cleanClassName}:
    """
    ${cleanClassName} (Selenium WebDriver Python POM)
    Generated automatically by XPath & Selector Generation Copilot
    """

    # Locators
${locators}

    def __init__(self, driver: WebDriver):
        self.driver = driver

${methods}
`;
  }

  // Cypress
  const commands = elements
    .map(el => `Cypress.Commands.add('get${el.elementName.charAt(0).toUpperCase() + el.elementName.slice(1)}', () => {
  return ${el.cypressLocator};
});`)
    .join('\n\n');

  return `// ${cleanClassName} Custom Cypress Commands
// Generated automatically by XPath & Selector Generation Copilot

${commands}
`;
}

/**
 * Generates test automation code snippets across Selenium, Playwright, Cypress, etc.
 */
export function generateFrameworkSnippets(
  xpath: string,
  cssSelector: string | null,
  playwrightSemantic: string
) {
  const cleanXpath = xpath.replace(/'/g, "\\'");
  const cleanCss = cssSelector ? cssSelector.replace(/'/g, "\\'") : null;

  return {
    seleniumJava: `// Selenium WebDriver (Java)
WebElement element = driver.findElement(By.xpath("${xpath.replace(/"/g, '\\"')}"));
element.click();`,

    seleniumPython: `# Selenium WebDriver (Python)
from selenium.webdriver.common.by import By

element = driver.find_element(By.XPATH, "${xpath.replace(/"/g, '\\"')}")
element.click()`,

    playwrightTs: `// Playwright (TypeScript/JavaScript)
// Preferred semantic locator:
await ${playwrightSemantic}.click();

// Or explicit resilient XPath locator:
await page.locator('xpath=${cleanXpath}').click();`,

    playwrightPython: `# Playwright (Python)
# Semantic locator
page.locator('xpath=${xpath.replace(/'/g, "\\'")}').click()`,

    cypress: `// Cypress
// Using cypress-xpath plugin:
cy.xpath('${cleanXpath}').click();
${cleanCss ? `\n// Or standard CSS selector:\ncy.get('${cleanCss}').click();` : ''}`,

    robotFramework: `# Robot Framework (SeleniumLibrary)
Click Element    xpath=${xpath}`,

    puppeteer: `// Puppeteer
const [element] = await page.$x('${cleanXpath}');
if (element) await element.click();`,
  };
}
