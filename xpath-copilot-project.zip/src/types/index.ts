export interface CopilotResult {
  target_functionality: string;
  best_xpath: string;
  strategy_used: string;
  alternative_xpaths: string[];
  alternative_css_selector: string | null;
  playwright_semantic_locator: string;
  confidence_score: string | number;
  explanation: string;
  flakinessAudit?: FlakinessAudit;
  scenarioTags?: string[];
}

export interface FlakinessAudit {
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  score: number; // 0 - 100
  checks: {
    name: string;
    status: 'pass' | 'warn' | 'fail';
    detail: string;
  }[];
  recommendations: string[];
}

export interface EvaluationResult {
  isValidXPath: boolean;
  matchCount: number;
  matchedElements: MatchedElementSummary[];
  error?: string;
  strategyRating?: 'gold' | 'silver' | 'bronze' | 'warning';
  antiPatternWarnings: string[];
}

export interface MatchedElementSummary {
  index: number;
  tagName: string;
  id?: string;
  name?: string;
  testId?: string;
  textContent?: string;
  outerHTMLSnippet: string;
}

export interface ScenarioPreset {
  id: string;
  title: string;
  badge: string;
  category: 'e-commerce' | 'table' | 'shadow-dom' | 'svg' | 'forms' | 'toast' | 'iframe' | 'combobox' | 'auth';
  description: string;
  html: string;
  sampleQueries: string[];
  scenarioNotes?: string;
}

export interface HarvestedElement {
  id: string;
  elementName: string;
  tag: string;
  category: 'button' | 'input' | 'link' | 'select' | 'checkbox' | 'radio' | 'table' | 'svg' | 'custom' | 'other';
  bestXPath: string;
  cssSelector: string;
  playwrightLocator: string;
  cypressLocator: string;
  seleniumJava: string;
  seleniumPython: string;
  flakinessGrade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  testId?: string;
  elementText?: string;
  htmlSnippet: string;
}

export type PomFormat = 'playwright' | 'selenium-java' | 'selenium-python' | 'cypress';
