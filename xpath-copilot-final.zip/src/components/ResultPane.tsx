import React, { useState } from 'react';
import { 
  Check, 
  Copy, 
  ShieldCheck, 
  AlertTriangle, 
  ExternalLink, 
  Terminal, 
  CheckCircle, 
  Zap, 
  Sparkles, 
  Eye, 
  Crosshair, 
  Layers, 
  Info,
  ChevronRight,
  Code
} from 'lucide-react';
import { CopilotResult, EvaluationResult } from '../types';
import { evaluateXPath, evaluateCssSelector, generateFrameworkSnippets } from '../utils/domEvaluator';
import { ResilienceIndicator } from './ResilienceIndicator';

interface ResultPaneProps {
  result: CopilotResult | null;
  html: string;
  isLoading: boolean;
  onCustomTest?: (xpath: string) => void;
}

export const ResultPane: React.FC<ResultPaneProps> = ({
  result,
  html,
  isLoading,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeFramework, setActiveFramework] = useState<
    'seleniumJava' | 'seleniumPython' | 'playwrightTs' | 'cypress' | 'robotFramework' | 'puppeteer'
  >('playwrightTs');
  const [customXPath, setCustomXPath] = useState<string>('');
  const [customEval, setCustomEval] = useState<EvaluationResult | null>(null);
  const [selectedXPath, setSelectedXPath] = useState<string | null>(null);

  const activeXPath = selectedXPath || result?.best_xpath || '';

  // Evaluate the best XPath directly in-browser
  const bestXPathEval = result ? evaluateXPath(html, activeXPath) : null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleTestCustomXPath = (xpathToTest: string) => {
    setSelectedXPath(xpathToTest);
    setCustomXPath(xpathToTest);
    const evaluation = evaluateXPath(html, xpathToTest);
    setCustomEval(evaluation);
  };

  const handleApplyRefactor = (refactoredXPath: string) => {
    setSelectedXPath(refactoredXPath);
    setCustomXPath(refactoredXPath);
    handleTestCustomXPath(refactoredXPath);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[450px] bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center">
        <div className="relative mb-6">
          <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center animate-pulse">
            <Crosshair className="w-8 h-8 text-indigo-400 animate-spin" />
          </div>
          <div className="absolute inset-0 rounded-2xl bg-indigo-500/20 blur-xl -z-10 animate-pulse" />
        </div>
        <h3 className="text-base font-bold text-white mb-2">Analyzing DOM Hierarchy & Resiliency</h3>
        <p className="text-xs text-slate-400 max-w-sm mb-6">
          Auditing candidate locators against the 5-tier Priority Hierarchy (QA Attributes → Unique Identifiers → Semantic Text → Relational Axes → Partial Matches)...
        </p>
        <div className="w-full max-w-xs bg-slate-950 rounded-full h-1.5 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 animate-[shimmer_1.5s_infinite] w-full" />
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[450px] bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
        <div className="w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center mb-4">
          <Sparkles className="w-7 h-7 text-indigo-400" />
        </div>
        <h3 className="text-base font-bold text-slate-200 mb-1">Locator Copilot Ready</h3>
        <p className="text-xs text-slate-400 max-w-sm mb-4">
          Select a scenario template or paste an HTML snippet on the left, specify your target element, and click <strong>Generate</strong>.
        </p>
        <div className="text-xs bg-slate-950/70 border border-slate-800 rounded-xl p-3 text-left max-w-xs space-y-1.5 text-slate-400">
          <div className="text-[11px] font-bold uppercase text-slate-500">Guaranteed Compliance:</div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Check className="w-3.5 h-3.5 text-emerald-400" /> Strict 5-tier priority selection
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Check className="w-3.5 h-3.5 text-emerald-400" /> Anti-pattern rejection (no /html/body)
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Check className="w-3.5 h-3.5 text-emerald-400" /> Live in-browser DOM verification
          </div>
        </div>
      </div>
    );
  }

  const codeSnippets = generateFrameworkSnippets(
    result.best_xpath,
    result.alternative_css_selector,
    result.playwright_semantic_locator
  );

  const getStrategyBadgeColor = (strategy: string) => {
    const s = strategy.toLowerCase();
    if (s.includes('qa') || s.includes('testid')) return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
    if (s.includes('unique') || s.includes('persistent') || s.includes('id')) return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
    if (s.includes('text') || s.includes('semantic') || s.includes('normalize')) return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
    if (s.includes('axis') || s.includes('relational') || s.includes('sibling')) return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
  };

  const confidenceNum = typeof result.confidence_score === 'number' 
    ? result.confidence_score 
    : parseFloat(result.confidence_score) || 0.95;

  return (
    <div className="flex flex-col h-full space-y-4 overflow-y-auto pr-1">
      {/* Primary Hero Card: THE BEST XPATH */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950/20 to-slate-900 border-2 border-indigo-500/40 rounded-2xl p-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -z-10" />

        {/* Top Badges & Confidence */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-md bg-indigo-500 text-white shadow-sm flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 fill-current" />
              BEST XPATH
            </span>
            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${getStrategyBadgeColor(result.strategy_used)}`}>
              {result.strategy_used}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 text-xs text-slate-300">
              <span className="text-[11px] uppercase font-bold text-slate-400">Confidence:</span>
              <span className="font-mono font-bold text-emerald-400">
                {(confidenceNum * 100).toFixed(0)}%
              </span>
            </div>
            {/* Visual Confidence Bar */}
            <div className="w-16 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full"
                style={{ width: `${Math.min(confidenceNum * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* XPath Code Display Box */}
        <div className="relative group mb-3.5">
          <div className="w-full bg-slate-950 border border-slate-700/80 rounded-xl p-3.5 font-mono text-sm text-indigo-200 break-all select-all shadow-inner flex items-center justify-between gap-3">
            <div className="space-y-1 overflow-hidden pr-2">
              {selectedXPath && selectedXPath !== result.best_xpath && (
                <div className="flex items-center gap-2 text-[10px] text-amber-400 font-sans">
                  <span>Inspecting Custom/Backup Selector</span>
                  <button
                    onClick={() => {
                      setSelectedXPath(null);
                      setCustomXPath('');
                    }}
                    className="underline text-indigo-400 hover:text-indigo-300 font-medium"
                  >
                    Reset to Best XPath
                  </button>
                </div>
              )}
              <span className="font-semibold text-emerald-300 block">{activeXPath}</span>
            </div>
            <button
              onClick={() => copyToClipboard(activeXPath, 'best_xpath')}
              className="flex-shrink-0 p-2 rounded-lg bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white transition flex items-center gap-1.5 text-xs font-medium"
              title="Copy active XPath to clipboard"
            >
              {copiedKey === 'best_xpath' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span className="text-emerald-300">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live DOM Match Verification Status */}
        {bestXPathEval && (
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs mb-3.5">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-medium">In-Browser DOM Match:</span>
              {bestXPathEval.isValidXPath ? (
                bestXPathEval.matchCount === 1 ? (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/40">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    1 Unique Match (Optimal & Unambiguous)
                  </span>
                ) : bestXPathEval.matchCount > 1 ? (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    {bestXPathEval.matchCount} Matches (Ambiguous locator)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/40">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    0 Matches in current DOM snippet
                  </span>
                )
              ) : (
                <span className="text-rose-400">{bestXPathEval.error}</span>
              )}
            </div>

            {bestXPathEval.matchedElements.length > 0 && (
              <span className="text-slate-400 font-mono text-[11px]">
                Matched: &lt;{bestXPathEval.matchedElements[0].tagName}
                {bestXPathEval.matchedElements[0].id ? ` id="${bestXPathEval.matchedElements[0].id}"` : ''}&gt;
              </span>
            )}
          </div>
        )}

        {/* Explanation Callout */}
        <div className="text-xs text-slate-300 bg-slate-900/60 rounded-xl p-3 border border-slate-800 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-white">Architect's Rationale: </strong>
            {result.explanation}
          </p>
        </div>
      </div>

      {/* Resilience Indicator Component */}
      <ResilienceIndicator 
        xpath={activeXPath} 
        html={html} 
        onApplyRefactor={handleApplyRefactor} 
      />

      {/* Alternative Backup Selectors & Playwright Semantic */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-indigo-400" />
          Alternative Resilient Selectors & Playwright Semantic
        </h4>

        {/* Playwright Semantic Locator */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-indigo-400 flex items-center gap-1">
              <span>🎭 Playwright Semantic Locator</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 font-normal">Recommended for Playwright</span>
            </span>
            <button
              onClick={() => copyToClipboard(result.playwright_semantic_locator, 'playwright_semantic')}
              className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
            >
              {copiedKey === 'playwright_semantic' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedKey === 'playwright_semantic' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <div className="font-mono text-xs text-indigo-300 bg-slate-900/80 p-2 rounded-lg border border-slate-800 break-all select-all">
            {result.playwright_semantic_locator}
          </div>
        </div>

        {/* Equivalent CSS Selector */}
        {result.alternative_css_selector && (
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-blue-400">Equivalent CSS Selector</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleTestCustomXPath(`//${result.alternative_css_selector}`)}
                  className="text-[11px] text-indigo-400 hover:text-indigo-300 underline"
                >
                  Test
                </button>
                <button
                  onClick={() => copyToClipboard(result.alternative_css_selector!, 'css_selector')}
                  className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                >
                  {copiedKey === 'css_selector' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'css_selector' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
            <div className="font-mono text-xs text-blue-300 bg-slate-900/80 p-2 rounded-lg border border-slate-800 break-all select-all">
              {result.alternative_css_selector}
            </div>
          </div>
        )}

        {/* Backup XPaths */}
        {result.alternative_xpaths && result.alternative_xpaths.length > 0 && (
          <div className="space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Backup Alternative XPaths:
            </div>
            {result.alternative_xpaths.map((xpath, idx) => {
              const evalRes = evaluateXPath(html, xpath);
              return (
                <div key={idx} className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono text-slate-500">Backup #{idx + 1}</span>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        evalRes.matchCount === 1 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {evalRes.matchCount} match{evalRes.matchCount === 1 ? '' : 'es'}
                      </span>
                      <button
                        onClick={() => handleTestCustomXPath(xpath)}
                        className="text-[11px] text-indigo-400 hover:text-indigo-300 underline"
                      >
                        Inspect
                      </button>
                      <button
                        onClick={() => copyToClipboard(xpath, `alt_${idx}`)}
                        className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                      >
                        {copiedKey === `alt_${idx}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedKey === `alt_${idx}` ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                  <div className="font-mono text-xs text-slate-300 break-all select-all">
                    {xpath}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Live Custom XPath Sandbox & Match Inspector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-indigo-400" />
            Live XPath Tester & Match Inspector
          </h4>
          <span className="text-[11px] text-slate-500">Test or fine-tune against DOM</span>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={customXPath}
            onChange={(e) => {
              const val = e.target.value;
              setCustomXPath(val);
              setSelectedXPath(val.trim() ? val : null);
              setCustomEval(evaluateXPath(html, val));
            }}
            placeholder="Type or tweak an XPath to evaluate..."
            className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
          <button
            onClick={() => handleTestCustomXPath(customXPath || result.best_xpath)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition"
          >
            Evaluate
          </button>
        </div>

        {customEval && (
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-medium text-slate-300">
                Matches Found: <strong className={customEval.matchCount === 1 ? 'text-emerald-400' : 'text-amber-400'}>{customEval.matchCount}</strong>
              </span>
              {customEval.error && <span className="text-rose-400">{customEval.error}</span>}
            </div>

            {customEval.antiPatternWarnings.length > 0 && (
              <div className="space-y-1">
                {customEval.antiPatternWarnings.map((warn, i) => (
                  <div key={i} className="text-[11px] text-amber-300 bg-amber-950/40 p-1.5 rounded border border-amber-800/40 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <span>{warn}</span>
                  </div>
                ))}
              </div>
            )}

            {customEval.matchedElements.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="text-[11px] text-slate-500 font-mono uppercase font-bold">Matched Elements:</div>
                {customEval.matchedElements.map((el, i) => (
                  <div key={i} className="p-2 rounded bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1">
                    <div className="flex items-center justify-between text-indigo-300">
                      <span>#{el.index} &lt;{el.tagName}&gt;</span>
                      {el.testId && <span className="text-emerald-400">testid: {el.testId}</span>}
                    </div>
                    {el.outerHTMLSnippet && (
                      <div className="text-slate-400 truncate text-[10px]">
                        {el.outerHTMLSnippet}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Multi-Framework Automation Code Snippets */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Code className="w-4 h-4 text-indigo-400" />
            Automation Framework Code (Ready-to-Paste)
          </h4>
          <button
            onClick={() => copyToClipboard(codeSnippets[activeFramework], 'framework_code')}
            className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 self-start sm:self-auto"
          >
            {copiedKey === 'framework_code' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedKey === 'framework_code' ? 'Code Copied!' : 'Copy Snippet'}</span>
          </button>
        </div>

        {/* Framework Tabs */}
        <div className="flex flex-wrap gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveFramework('playwrightTs')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'playwrightTs' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Playwright (TS)
          </button>
          <button
            onClick={() => setActiveFramework('seleniumJava')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'seleniumJava' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Selenium (Java)
          </button>
          <button
            onClick={() => setActiveFramework('seleniumPython')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'seleniumPython' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Selenium (Python)
          </button>
          <button
            onClick={() => setActiveFramework('cypress')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'cypress' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cypress
          </button>
          <button
            onClick={() => setActiveFramework('robotFramework')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'robotFramework' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Robot Framework
          </button>
          <button
            onClick={() => setActiveFramework('puppeteer')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              activeFramework === 'puppeteer' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Puppeteer
          </button>
        </div>

        {/* Code Block */}
        <pre className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed select-all">
          {codeSnippets[activeFramework]}
        </pre>
      </div>
    </div>
  );
};
