import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { EditorPane } from './components/EditorPane';
import { ResultPane } from './components/ResultPane';
import { RawJsonViewer } from './components/RawJsonViewer';
import { ElementHarvesterView } from './components/ElementHarvesterView';
import { SpecificationModal } from './components/SpecificationModal';
import { UrlFetchModal } from './components/UrlFetchModal';
import { ExportProjectModal } from './components/ExportProjectModal';
import { SCENARIO_PRESETS } from './data/presets';
import { CopilotResult, ScenarioPreset } from './types';
import { AlertCircle } from 'lucide-react';

export default function App() {
  const [activePreset, setActivePreset] = useState<ScenarioPreset>(SCENARIO_PRESETS[0]);
  const [html, setHtml] = useState<string>(SCENARIO_PRESETS[0].html);
  const [targetFunctionality, setTargetFunctionality] = useState<string>(
    SCENARIO_PRESETS[0].sampleQueries[0]
  );
  const [result, setResult] = useState<CopilotResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [aiSource, setAiSource] = useState<string>('not-run-yet');
  const [viewMode, setViewMode] = useState<'studio' | 'harvester' | 'json'>('studio');
  const [isRulesModalOpen, setIsRulesModalOpen] = useState<boolean>(false);
  const [isUrlModalOpen, setIsUrlModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Generate selector from backend API
  const handleGenerate = useCallback(async () => {
    if (!html.trim() || !targetFunctionality.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-xpath', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          html,
          targetFunctionality,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}: ${response.statusText}`);
      }

      const json = await response.json();
      if (json.success && json.data) {
        setResult(json.data);
        setAiSource(json.note && String(json.note).startsWith('Gemini unavailable') ? `${json.source || 'offline'} (Gemini unavailable)` : json.source || 'unknown');
      } else {
        throw new Error(json.error || 'Failed to generate selector');
      }
    } catch (err: any) {
      console.error('Generation failed:', err);
      setError(err?.message || 'Could not reach the Copilot server. Is `npm run dev` running?');
    } finally {
      setIsLoading(false);
    }
  }, [html, targetFunctionality]);

  // Initial generation on first mount so the user has an instant interactive playground
  useEffect(() => {
    handleGenerate();
  }, []);

  const handleSelectPreset = (preset: ScenarioPreset) => {
    setActivePreset(preset);
    setHtml(preset.html);
    setTargetFunctionality(preset.sampleQueries[0]);
  };

  const handleUrlFetched = (fetchedHtml: string, title?: string, url?: string) => {
    setHtml(fetchedHtml);
    setResult(null);
    const pageTitle = title || url || 'Live Web Page';
    setTargetFunctionality(`Find the primary action button on ${pageTitle}`);
    setActivePreset({
      id: 'custom-fetched-url',
      title: pageTitle.slice(0, 30),
      badge: 'Live URL',
      category: 'forms',
      description: `Fetched from ${url}`,
      html: fetchedHtml,
      sampleQueries: [
        `Find the primary navigation or submit button on ${pageTitle}`,
        `Find the search input field`,
        `Find the main call-to-action button`,
      ],
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* App Header */}
      <Header
        viewMode={viewMode}
        onToggleViewMode={setViewMode}
        onOpenRules={() => setIsRulesModalOpen(true)}
        onOpenUrlModal={() => setIsUrlModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        aiSource={aiSource}
      />

      {/* Error Alert Bar */}
      {error && (
        <div className="bg-rose-950/80 border-b border-rose-800/80 px-4 py-2.5 flex items-center justify-between text-xs text-rose-200">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="underline text-rose-300">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 flex flex-col">
        {viewMode === 'studio' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-[600px]">
            {/* Left: Input Editor & Inspector */}
            <div className="flex flex-col h-full">
              <EditorPane
                html={html}
                setHtml={setHtml}
                targetFunctionality={targetFunctionality}
                setTargetFunctionality={setTargetFunctionality}
                onGenerate={handleGenerate}
                isLoading={isLoading}
                activePresetId={activePreset.id}
                onSelectPreset={handleSelectPreset}
                onOpenUrlModal={() => setIsUrlModalOpen(true)}
              />
            </div>

            {/* Right: Gold Standard Result & Automation Codes */}
            <div className="flex flex-col h-full">
              <ResultPane
                result={result}
                html={html}
                isLoading={isLoading}
              />
            </div>
          </div>
        ) : viewMode === 'harvester' ? (
          <div className="w-full flex-1">
            <ElementHarvesterView
              html={html}
            />
          </div>
        ) : (
          <div className="w-full max-w-4xl mx-auto flex-1">
            <RawJsonViewer
              result={result}
              html={html}
              targetFunctionality={targetFunctionality}
            />
          </div>
        )}
      </main>

      {/* Specification & Architecture Cheatsheet Modal */}
      <SpecificationModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
      />

      {/* Live Web Page URL Fetcher Modal */}
      <UrlFetchModal
        isOpen={isUrlModalOpen}
        onClose={() => setIsUrlModalOpen(false)}
        onUrlFetched={handleUrlFetched}
      />

      {/* Export Project for VS Code Modal */}
      <ExportProjectModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />
    </div>
  );
}
