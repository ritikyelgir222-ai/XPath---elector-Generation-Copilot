/**
 * Offline DOM-based locator engine.
 *
 * 1. Parses the HTML (jsdom) and inflates <iframe> bodies so frame content is searchable.
 * 2. Scores every element against the natural-language request (visible text, aria-label,
 *    placeholder, label association, test ids, type hints, row/host context).
 * 3. Builds locator candidates in strict priority order (Tier 1 -> 5) and VERIFIES each one
 *    against the DOM, keeping only locators that match exactly the chosen element.
 */
import { JSDOM } from 'jsdom';

export interface HeuristicResult {
  target_functionality: string;
  best_xpath: string;
  strategy_used: string;
  alternative_xpaths: string[];
  alternative_css_selector: string | null;
  playwright_semantic_locator: string;
  confidence_score: string;
  explanation: string;
}

interface Loc {
  xpath: string;
  tier: 1 | 2 | 3 | 4 | 5 | 6;
  label: string;
  note?: string;
}

const QA_ATTRS = ['data-testid', 'data-qa', 'data-cy', 'data-test'];
const SKIP_TAGS = new Set(['html', 'head', 'body', 'script', 'style', 'meta', 'link', 'title', 'br', 'noscript', 'template']);
const SVG_INNER = new Set(['path', 'g', 'circle', 'rect', 'line', 'polyline', 'polygon', 'defs', 'use', 'ellipse', 'text', 'tspan']);
const STOP = new Set(
  ('find locate get select the a an in on of for to with inside within next near by at from that this its it and or is are ' +
    'element elements field fields item please give me xpath selector locator target which where whose into under over ' +
    'label row table form section widget modal dialog panel container area page one first last').split(' ')
);
const TYPE_WORDS: Record<string, string> = {
  button: 'button', btn: 'button', submit: 'button',
  link: 'link', anchor: 'link', hyperlink: 'link',
  input: 'input', textbox: 'input', textfield: 'input', box: 'input', password: 'input', search: 'input-soft',
  checkbox: 'checkbox', radio: 'radio', dropdown: 'select', select: 'select', combobox: 'select', listbox: 'select',
  option: 'option', toast: 'alert', alert: 'alert', notification: 'alert', snackbar: 'alert', banner: 'alert',
  iframe: 'iframe', frame: 'iframe', image: 'img', img: 'img', icon: 'button-soft', heading: 'heading', title: 'heading',
  tab: 'tab', menu: 'menu', textarea: 'input',
};

const norm = (s: string | null | undefined) => (s ?? '').replace(/\s+/g, ' ').trim();

function xq(s: string): string {
  if (!s.includes("'")) return `'${s}'`;
  if (!s.includes('"')) return `"${s}"`;
  return 'concat(' + s.split("'").map((p) => `'${p}'`).join(`, "'", `) + ')';
}

function isDynamicToken(v: string): boolean {
  return (
    /^(css|sc|jsx|ember|react|mui|chakra|radix|headlessui|:r)/i.test(v) ||
    /\d{4,}/.test(v) ||
    /[0-9a-f]{8,}/i.test(v) ||
    /^[a-z]{1,3}-?[0-9a-z]{5,8}$/i.test(v) && /\d/.test(v) && /[a-z]/i.test(v) && !/[-_ ]/.test(v) && v.length <= 9
  );
}

function words(s: string): string[] {
  return s
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    .map(stem);
}
function stem(w: string): string {
  return w.length > 3 && w.endsWith('s') && !w.endsWith('ss') ? w.slice(0, -1) : w;
}

function implicitRole(el: Element): string {
  const explicit = el.getAttribute('role');
  if (explicit) return explicit;
  const tag = el.tagName.toLowerCase();
  const type = (el.getAttribute('type') || 'text').toLowerCase();
  switch (tag) {
    case 'button': return 'button';
    case 'a': return el.hasAttribute('href') ? 'link' : '';
    case 'select': return 'combobox';
    case 'textarea': return 'textbox';
    case 'img': return 'img';
    case 'tr': return 'row';
    case 'li': return 'listitem';
    case 'table': return 'table';
    case 'iframe': return 'iframe';
    case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6': return 'heading';
    case 'input':
      if (type === 'checkbox') return 'checkbox';
      if (type === 'radio') return 'radio';
      if (['submit', 'button', 'reset', 'image'].includes(type)) return 'button';
      if (type === 'range') return 'slider';
      if (['hidden', 'password'].includes(type)) return '';
      return 'textbox';
    default: return '';
  }
}

const isInteractive = (el: Element) =>
  ['button', 'a', 'input', 'select', 'textarea'].includes(el.tagName.toLowerCase()) ||
  ['button', 'link', 'checkbox', 'radio', 'textbox', 'combobox', 'option', 'tab', 'menuitem', 'switch'].includes(el.getAttribute('role') || '');

function directText(el: Element): string {
  let t = '';
  el.childNodes.forEach((n) => { if (n.nodeType === 3) t += ' ' + n.textContent; });
  return norm(t);
}

const TEXTY = new Set(['button', 'a', 'label', 'li', 'td', 'th', 'option', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'summary', 'legend', 'caption', 'p', 'span', 'small', 'strong', 'em', 'b', 'i']);
const TEXTY_ROLES = new Set(['alert', 'status', 'dialog', 'tooltip', 'option', 'menuitem', 'tab', 'heading', 'button', 'link']);

function ownText(el: Element): string {
  const tag = el.tagName.toLowerCase();
  const role = el.getAttribute('role') || '';
  const leaf = el.children.length === 0;
  if (tag === 'input') return '';
  if (leaf || TEXTY.has(tag) || TEXTY_ROLES.has(role)) {
    const t = norm(el.textContent);
    const limit = ['alert', 'status', 'dialog'].includes(role) ? 400 : 140;
    return t.length <= limit ? t : directText(el);
  }
  return directText(el);
}

interface LabelInfo { text: string; node: Element; rel: 'for' | 'wrap' | 'before' | 'after' }

function labelFor(el: Element): LabelInfo | null {
  const tag = el.tagName.toLowerCase();
  if (!['input', 'select', 'textarea'].includes(tag)) return null;
  const doc = el.ownerDocument;
  const id = el.getAttribute('id');
  if (id) {
    const l = Array.from(doc.querySelectorAll('label')).find((x) => x.getAttribute('for') === id);
    if (l) return { text: norm(l.textContent), node: l, rel: 'for' };
  }
  const wrap = el.closest('label');
  if (wrap) return { text: norm(wrap.textContent), node: wrap, rel: 'wrap' };
  const type = (el.getAttribute('type') || '').toLowerCase();
  // preceding sibling label / text element
  let p = el.previousElementSibling;
  while (p) {
    if (p.tagName.toLowerCase() === 'label' || (!isInteractive(p) && norm(p.textContent) && p.children.length === 0 && ['span', 'p', 'small', 'div', 'strong', 'b'].includes(p.tagName.toLowerCase()) && !['checkbox', 'radio'].includes(type))) {
      return { text: norm(p.textContent), node: p, rel: 'before' };
    }
    p = p.previousElementSibling;
    break;
  }
  if (['checkbox', 'radio'].includes(type)) {
    const n = el.nextElementSibling;
    if (n && norm(n.textContent) && !isInteractive(n)) return { text: norm(n.textContent), node: n, rel: 'after' };
  }
  // label earlier inside the same parent group
  const par = el.parentElement;
  if (par) {
    const l = par.querySelector(':scope > label');
    if (l && l !== el) return { text: norm(l.textContent), node: l, rel: 'before' };
  }
  return null;
}

interface Info {
  el: Element;
  tag: string;
  role: string;
  text: string;
  aria: string;
  title: string;
  placeholder: string;
  name: string;
  id: string;
  testid: { attr: string; val: string } | null;
  alt: string;
  value: string;
  label: LabelInfo | null;
  type: string;
  header: string;
}

function columnHeader(el: Element): string {
  const td = el.closest('td');
  const table = td?.closest('table');
  if (!td || !table || !td.parentElement) return '';
  const idx = Array.from(td.parentElement.children).indexOf(td);
  const ths = table.querySelectorAll('thead th, tr:first-child th');
  const th = ths[idx];
  return th ? norm(th.textContent) : '';
}

function info(el: Element): Info {
  const tag = el.tagName.toLowerCase();
  let testid: Info['testid'] = null;
  for (const a of QA_ATTRS) if (el.getAttribute(a)) { testid = { attr: a, val: el.getAttribute(a)! }; break; }
  return {
    el, tag, role: implicitRole(el),
    text: ownText(el),
    aria: norm(el.getAttribute('aria-label')),
    title: norm(el.getAttribute('title')),
    placeholder: norm(el.getAttribute('placeholder')),
    name: norm(el.getAttribute('name')),
    id: norm(el.getAttribute('id')),
    testid,
    alt: norm(el.getAttribute('alt')),
    value: ['submit', 'button', 'reset'].includes((el.getAttribute('type') || '').toLowerCase()) ? norm(el.getAttribute('value')) : '',
    label: labelFor(el),
    type: (el.getAttribute('type') || '').toLowerCase(),
    header: columnHeader(el),
  };
}

/** Accessible-ish display name used for Playwright role locators. */
function accName(i: Info): string {
  return i.aria || (i.label?.text ?? '') || i.text || i.value || i.alt || i.title || i.placeholder;
}

function hintMatches(hint: string, i: Info): boolean {
  switch (hint) {
    case 'button': return i.role === 'button' || i.tag === 'button';
    case 'button-soft': return i.role === 'button';
    case 'link': return i.role === 'link';
    case 'input': return ['input', 'textarea'].includes(i.tag) && !['checkbox', 'radio', 'submit', 'button'].includes(i.type);
    case 'input-soft': return ['input', 'textarea'].includes(i.tag);
    case 'checkbox': return i.type === 'checkbox' || i.role === 'checkbox';
    case 'radio': return i.type === 'radio' || i.role === 'radio';
    case 'select': return i.tag === 'select' || ['combobox', 'listbox'].includes(i.role);
    case 'option': return i.tag === 'option' || i.role === 'option';
    case 'alert': return ['alert', 'status'].includes(i.role) || /alert|toast|notif|snack|banner/i.test(i.el.getAttribute('class') || '');
    case 'iframe': return i.tag === 'iframe';
    case 'img': return i.tag === 'img' || i.tag === 'svg' || i.role === 'img';
    case 'heading': return i.role === 'heading';
    case 'tab': return i.role === 'tab';
    case 'menu': return i.role.startsWith('menu');
  }
  return false;
}

function ancestors(el: Element, max = 8): Element[] {
  const out: Element[] = [];
  let p = el.parentElement;
  while (p && out.length < max && !['body', 'html'].includes(p.tagName.toLowerCase())) { out.push(p); p = p.parentElement; }
  return out;
}

// ---------------------------------------------------------------------------------------------

export function generateHeuristicSelector(html: string, query: string): HeuristicResult {
  const dom = new JSDOM(html);
  const doc = dom.window.document;
  const win = dom.window;

  // Inflate iframe contents (HTML parsers treat them as raw text).
  doc.querySelectorAll('iframe').forEach((f) => {
    const raw = f.textContent || '';
    if (raw.includes('<')) {
      const holder = doc.createElement('div');
      holder.innerHTML = raw;
      f.textContent = '';
      Array.from(holder.childNodes).forEach((c) => f.appendChild(c));
    }
  });

  const count = (xp: string): { n: number; first: Node | null } => {
    try {
      const snap = doc.evaluate(xp, doc, null, win.XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return { n: snap.snapshotLength, first: snap.snapshotLength ? snap.snapshotItem(0) : null };
    } catch {
      return { n: -1, first: null };
    }
  };

  // ---- parse the request: split "<target> <preposition> <context>"
  const q = query.toLowerCase();
  const quoted = Array.from(query.matchAll(/["'“”‘’]([^"'“”‘’]{2,})["'“”‘’]/g)).map((m) => m[1].toLowerCase());
  const splitAt = q.search(/\b(?:for|of|in|inside|within|next to|near|under|on|belonging to|from|at)\b/);
  let targetQ = splitAt > 0 ? q.slice(0, splitAt) : q;
  let contextQ = splitAt > 0 ? q.slice(splitAt) : '';
  const tokenize = (str: string) => str.split(/[^a-z0-9]+/).filter(Boolean);
  const hasContent = (str: string) => tokenize(str).some((w) => !STOP.has(w) && !TYPE_WORDS[w]);
  if (!hasContent(targetQ)) { targetQ = q; contextQ = ''; }
  const hints = new Set<string>();
  tokenize(targetQ).forEach((w) => { if (TYPE_WORDS[w]) hints.add(TYPE_WORDS[w]); });
  const wantsSubmit = tokenize(targetQ).includes('submit');
  const targetTokens = Array.from(new Set(tokenize(targetQ).filter((w) => !STOP.has(w) && !TYPE_WORDS[w]).map(stem)));
  const contextTokens = Array.from(new Set(tokenize(contextQ).filter((w) => !STOP.has(w) && !TYPE_WORDS[w]).map(stem))).filter((t) => !targetTokens.includes(t));
  const tokens = [...targetTokens, ...contextTokens];
  const typeAsContent = Array.from(new Set(tokenize(targetQ).filter((w) => TYPE_WORDS[w] && !STOP.has(w)).map(stem)));

  // ---- gather and score candidates
  const all = Array.from(doc.body.querySelectorAll('*')).filter((e) => {
    const t = e.tagName.toLowerCase();
    if (SKIP_TAGS.has(t)) return false;
    if (SVG_INNER.has(t) && e.closest('svg') && t !== 'svg') return false;
    if (e.tagName.toLowerCase() === 'input' && (e.getAttribute('type') || '').toLowerCase() === 'hidden') return false;
    return true;
  });

  let best: { i: Info; score: number } | null = null;
  const second: number[] = [];
  for (const el of all) {
    const i = info(el);
    const fields = [i.text, i.aria, i.title, i.placeholder, i.alt, i.value, i.label?.text ?? '', i.name, i.id.replace(/[-_]/g, ' '), i.testid?.val ?? '', i.header];
    const hay = new Set(words(fields.join(' ')));
    const clsWords = new Set(words(el.getAttribute('class') || ''));
    let score = 0;
    const match = (t: string, weight: number) => {
      if (hay.has(t)) return weight;
      if (t.length >= 4 && Array.from(hay).some((h) => h.length >= 4 && (h.startsWith(t) || t.startsWith(h)))) return weight / 2;
      if (clsWords.has(t)) return weight / 2;
      return 0;
    };
    for (const t of targetTokens) score += match(t, 3);
    for (const t of contextTokens) score += match(t, 1.2);
    for (const t of typeAsContent) if (i.type === t || i.name.toLowerCase() === t) score += 1;

    // whole visible label mentioned in the request (strong when it is the target part)
    for (const f of [i.text, i.aria, i.label?.text ?? '', i.placeholder, i.title, i.value]) {
      const lf = f.toLowerCase();
      if (lf.length >= 3 && /[a-z0-9]/.test(lf)) {
        if (targetQ.includes(lf)) { score += 5 + Math.min(4, words(lf).length); break; }
        if (q.includes(lf)) { score += 1.5; break; }
      }
    }
    for (const qu of quoted) if (fields.some((f) => f.toLowerCase().includes(qu))) score += 6;

    // "submit" intent: real submit controls
    if (wantsSubmit && (i.type === 'submit' || (i.tag === 'button' && !i.type && el.closest('form')))) score += 5;

    // type hint
    const hintOk = hints.size ? Array.from(hints).some((h) => hintMatches(h, i)) : false;
    if (hints.size) score += hintOk ? 4 : -6;
    if (i.tag === 'th' && contextTokens.length) score -= 6;
    else if (isInteractive(el)) score += 1;

    // context: ancestors (row-like, custom-element hosts, labelled/id'd containers) mentioning tokens
    {
      let ctx = 0;
      for (const a of ancestors(el, 6)) {
        const at = a.tagName.toLowerCase();
        const rowLike = ['tr', 'li', 'article'].includes(at) || ['row', 'listitem', 'group', 'listbox', 'dialog', 'form'].includes(a.getAttribute('role') || '');
        const meta = words([at, a.getAttribute('id') || '', a.getAttribute('aria-label') || '', a.getAttribute('data-testid') || '', a.getAttribute('class') || ''].join(' '));
        const txt = rowLike ? new Set(words(norm(a.textContent).slice(0, 400))) : new Set<string>();
        for (const t of [...contextTokens, ...targetTokens]) {
          if (hay.has(t)) continue;
          if (meta.includes(t) || txt.has(t)) ctx += contextTokens.includes(t) ? 1.2 : 0.6;
        }
      }
      score += Math.min(ctx, 6);
    }
    // an element that earned nothing from its own words/classes and no hint is not a candidate
    if (score <= 0 || (!hintOk && !wantsSubmit && targetTokens.every((t) => match(t, 3) === 0) && contextTokens.every((t) => match(t, 1) === 0))) continue;
    if (i.text.length > 120) score -= 2;
    if (!best || score > best.score) { if (best) second.push(best.score); best = { i, score }; }
    else second.push(score);
  }

  if (!best || best.score < 2) {
    return {
      target_functionality: query,
      best_xpath: '',
      strategy_used: 'No Confident Match',
      alternative_xpaths: [],
      alternative_css_selector: null,
      playwright_semantic_locator: '',
      confidence_score: '0.10',
      explanation: 'No element in the supplied HTML clearly matches this request. Use words that appear on the element (its label, text, placeholder or aria-label) or include more of the page HTML.',
    };
  }

  const { i } = best;
  const el = i.el;
  const tag = i.tag;
  const runnerUp = second.length ? Math.max(...second) : 0;
  const margin = best.score - runnerUp;

  // ---- context detection
  const iframeAnc = el.closest('iframe') && el.tagName.toLowerCase() !== 'iframe' ? el.closest('iframe') : null;
  const hostAnc = ancestors(el, 12).find((a) => a.tagName.includes('-') || a.tagName.toLowerCase().includes('-')) || null;

  // ---- predicate pieces for the target
  const preds: { p: string; tier: 1 | 2 | 3 | 5; label: string }[] = [];
  const stable = (v: string) => v && !isDynamicToken(v);
  if (i.testid) preds.push({ p: `@${i.testid.attr}=${xq(i.testid.val)}`, tier: 1, label: 'Standard QA Attribute (Gold Standard)' });
  if (stable(i.id)) preds.push({ p: `@id=${xq(i.id)}`, tier: 2, label: 'Unique Persistent Attribute' });
  if (stable(i.name) && tag !== 'meta') preds.push({ p: `@name=${xq(i.name)}`, tier: 2, label: 'Unique Persistent Attribute' });
  if (i.placeholder && /[A-Za-z0-9]/.test(i.placeholder)) preds.push({ p: `@placeholder=${xq(i.placeholder)}`, tier: 2, label: 'Unique Persistent Attribute' });
  const textOk = i.text && i.text.length <= 70 && /[A-Za-z0-9]/.test(i.text);
  if (textOk) preds.push({ p: `normalize-space()=${xq(i.text)}`, tier: 3, label: 'Semantic Text & Space Normalization' });
  if (i.value) preds.push({ p: `@value=${xq(i.value)}`, tier: 3, label: 'Semantic Text & Space Normalization' });
  const aria = i.aria ? { p: `@aria-label=${xq(i.aria)}`, tier: 2 as const, label: 'Accessible Name Attribute' } : null;
  if (aria && !textOk) preds.push(aria);
  if (i.title && !textOk && !aria) preds.push({ p: `@title=${xq(i.title)}`, tier: 2, label: 'Accessible Name Attribute' });
  if (i.alt) preds.push({ p: `@alt=${xq(i.alt)}`, tier: 2, label: 'Accessible Name Attribute' });

  const locs: Loc[] = [];
  const tagStep = tag.includes(':') ? `*[local-name()='${tag.split(':')[1]}']` : tag;
  const push = (l: Loc) => { if (!locs.some((x) => x.xpath === l.xpath)) locs.push(l); };

  // Tier 3: a child leaf's text mentioned in the request (e.g. <li><span>United States</span><span>US</span></li>)
  let childText = '';
  {
    const leaves = Array.from(el.querySelectorAll('*')).filter((n) => n.children.length === 0 && norm(n.textContent).length >= 3 && /[A-Za-z]/.test(norm(n.textContent)));
    const hit = leaves.find((n) => targetQ.includes(norm(n.textContent).toLowerCase()));
    if (hit && !el.getAttribute('data-testid') && el.children.length > 1) {
      childText = norm(hit.textContent);
      const ct = hit.tagName.toLowerCase();
      const roleP = el.getAttribute('role') ? `[@role=${xq(el.getAttribute('role')!)}]` : '';
      push({ xpath: `//${tagStep}${roleP}[.//${ct}[normalize-space()=${xq(childText)}]]`, tier: 3, label: 'Semantic Text & Space Normalization' });
    }
  }
  for (const p of preds) {
    push({ xpath: p.tier === 1 ? `//*[${p.p}]` : `//${tagStep}[${p.p}]`, tier: p.tier, label: p.label });
  }

  // Tier 4a: label relations
  if (i.label && i.label.text) {
    const L = i.label.node.tagName.toLowerCase();
    const lt = xq(i.label.text);
    const typeP = i.type ? `[@type=${xq(i.type)}]` : '';
    if (i.label.rel === 'before') {
      push({ xpath: `//${L}[normalize-space()=${lt}]/following-sibling::${tagStep}${typeP}[1]`, tier: 4, label: 'Relational & Axis Navigation' });
      push({ xpath: `//${L}[normalize-space()=${lt}]/following-sibling::${tagStep}[1]`, tier: 4, label: 'Relational & Axis Navigation' });
      push({ xpath: `//${L}[normalize-space()=${lt}]/..//${tagStep}${typeP}`, tier: 4, label: 'Relational & Axis Navigation' });
    } else if (i.label.rel === 'after') {
      push({ xpath: `//${L}[normalize-space()=${lt}]/preceding-sibling::${tagStep}[1]`, tier: 4, label: 'Relational & Axis Navigation' });
    } else if (i.label.rel === 'wrap') {
      push({ xpath: `//label[normalize-space()=${lt}]//${tagStep}`, tier: 4, label: 'Relational & Axis Navigation' });
    } else {
      push({ xpath: `//${tagStep}[@id=//label[normalize-space()=${lt}]/@for]`, tier: 4, label: 'Relational & Axis Navigation' });
    }
  }

  // Tier 4b: scoped by a row / container that has a unique anchor text
  const own = preds.find((p) => p.tier === 3) || preds.find((p) => p.tier === 2) || null;
  const pred = (extra: string) => (own ? `${tagStep}[${own.p}]` : tagStep) + extra;
  const textCount = new Map<string, number>();
  doc.body.querySelectorAll('*').forEach((n) => {
    if (n.children.length === 0) { const t = norm(n.textContent); if (t) textCount.set(t, (textCount.get(t) || 0) + 1); }
  });
  for (const a of ancestors(el, 6)) {
    const at = a.tagName.toLowerCase();
    // anchors: unique leaf texts inside this ancestor, preferring those mentioned in the request
    const anchors = Array.from(a.querySelectorAll('*'))
      .filter((n) => n !== el && !n.contains(el) && !el.contains(n) && n.children.length === 0)
      .map((n) => ({ n, t: norm(n.textContent) }))
      .filter((x) => x.t && x.t.length <= 50 && textCount.get(x.t) === 1 && /[A-Za-z0-9]/.test(x.t))
      .sort((x, y) => Number(q.includes(y.t.toLowerCase())) - Number(q.includes(x.t.toLowerCase())));
    for (const an of anchors.slice(0, 2)) {
      const anT = an.n.tagName.toLowerCase();
      const direct = an.n.parentElement === a;
      push({
        xpath: direct ? `//${at}[${anT}[normalize-space()=${xq(an.t)}]]//${pred('')}` : `//${at}[.//${anT}[normalize-space()=${xq(an.t)}]]//${pred('')}`,
        tier: 4, label: 'Relational & Axis Navigation',
      });
    }
    // stable container id / test id
    const cid = QA_ATTRS.map((x) => a.getAttribute(x) ? `@${x}=${xq(a.getAttribute(x)!)}` : '').find(Boolean) || (stable(norm(a.getAttribute('id'))) ? `@id=${xq(norm(a.getAttribute('id')))}` : '');
    if (cid) {
      push({ xpath: `//${at}[${cid}]//${pred('')}`, tier: 4, label: hostAnc === a ? 'Shadow DOM Host Traversal' : 'Relational & Axis Navigation' });
      if (i.type) push({ xpath: `//${at}[${cid}]//${tagStep}[@type=${xq(i.type)}]`, tier: 4, label: 'Relational & Axis Navigation' });
    }
  }

  // Tier 2b / 3b: attributes ignored earlier
  if (aria && textOk) push({ xpath: `//${tagStep}[${aria.p}]`, tier: 2, label: aria.label });
  if (i.title) push({ xpath: `//${tagStep}[@title=${xq(i.title)}]`, tier: 2, label: 'Accessible Name Attribute' });
  if (i.role === 'alert' || i.role === 'status') push({ xpath: `//*[@role=${xq(i.role)}]`, tier: 2, label: 'WAI-ARIA Semantic Role' });

  // Tier 5: partial matching
  if (stable(i.id)) {
    const pre = i.id.split(/[-_]/).slice(0, 2).join('-');
    if (pre && pre !== i.id) push({ xpath: `//${tagStep}[starts-with(@id, ${xq(pre)})]`, tier: 5, label: 'Partial Match & Normalization' });
  }
  if (textOk) push({ xpath: `//${tagStep}[contains(normalize-space(), ${xq(i.text.split(' ').slice(0, 3).join(' '))})]`, tier: 5, label: 'Partial Match & Normalization' });
  const cls = (el.getAttribute('class') || '').split(/\s+/).filter((c) => c && !isDynamicToken(c) && /^[a-z][a-z0-9_-]*$/i.test(c) && !/^(w|h|p|m|px|py|mx|my|mt|mb|ml|mr|text|bg|border|flex|grid|rounded|shadow|font|space|gap|hover|focus|transition|items|justify|block|inline|min|max|ring|tracking|cursor|overflow|opacity|z|top|left|right|bottom|absolute|relative|fixed)(-|$)/.test(c));
  if (cls.length) push({ xpath: `//${tagStep}[contains(concat(' ', normalize-space(@class), ' '), ${xq(' ' + cls[0] + ' ')})]`, tier: 5, label: 'Partial Match & Normalization' });

  if (i.type) push({ xpath: `//${tagStep}[@type=${xq(i.type)}]`, tier: 5, label: 'Partial Match & Normalization' });

  // verify
  const verified = locs.filter((l) => {
    const r = count(l.xpath);
    return r.n === 1 && r.first === el;
  });

  // last resort: positional
  if (!verified.length) {
    const sameTag = Array.from(doc.querySelectorAll(tag));
    const idx = sameTag.indexOf(el) + 1;
    verified.push({ xpath: `(//${tagStep})[${idx}]`, tier: 6, label: 'Positional (last resort)' });
  }
  // keep tier order but prefer shadow-host scoping for elements in custom elements when text is generic
  verified.sort((a, b) => a.tier - b.tier);
  const bestLoc = verified[0];

  // ---- CSS + Playwright
  const cssEsc = (s: string) => s.replace(/"/g, '\\"');
  let css: string | null = null;
  if (i.testid) css = `[${i.testid.attr}="${cssEsc(i.testid.val)}"]`;
  else if (stable(i.id) && /^[A-Za-z][\w-]*$/.test(i.id)) css = `#${i.id}`;
  else if (stable(i.name)) css = `${tag}[name="${cssEsc(i.name)}"]`;
  else if (i.aria) css = `${tag}[aria-label="${cssEsc(i.aria)}"]`;
  else if (i.placeholder) css = `${tag}[placeholder="${cssEsc(i.placeholder)}"]`;
  else if (cls.length) css = `${tag}.${cls[0]}`;
  if (css && hostAnc && !css.startsWith('#') && !css.startsWith('[data-')) css = `${hostAnc.tagName.toLowerCase()} ${css}`;

  const js = (s: string) => `'${s.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
  const nm = childText || accName(i);
  let pw: string;
  if (i.testid && i.testid.attr === 'data-testid') pw = `getByTestId(${js(i.testid.val)})`;
  else if (i.testid) pw = `locator(${js(`[${i.testid.attr}="${i.testid.val}"]`)})`;
  else if (i.role && i.role !== 'iframe' && nm && !['row', 'listitem', 'table'].includes(i.role)) pw = `getByRole(${js(i.role)}, { name: ${js(nm)} })`;
  else if (i.label?.text) pw = `getByLabel(${js(i.label.text)})`;
  else if (i.placeholder) pw = `getByPlaceholder(${js(i.placeholder)})`;
  else if (i.alt) pw = `getByAltText(${js(i.alt)})`;
  else if (i.text && i.text.length <= 70) pw = `getByText(${js(i.text)})`;
  else pw = `locator(${js(css ? css : 'xpath=' + bestLoc.xpath)})`;

  let root = 'page';
  const rowAnc = ancestors(el, 6).find((a) => ['tr'].includes(a.tagName.toLowerCase()) || a.getAttribute('role') === 'row' || a.tagName.toLowerCase() === 'li' || a.getAttribute('role') === 'listitem');
  const rowRole = rowAnc ? (rowAnc.getAttribute('role') || (rowAnc.tagName.toLowerCase() === 'li' ? 'listitem' : 'row')) : 'row';
  if (iframeAnc) {
    const fsel = iframeAnc.getAttribute('data-testid') ? `[data-testid="${iframeAnc.getAttribute('data-testid')}"]` : stable(norm(iframeAnc.getAttribute('id'))) ? `#${iframeAnc.getAttribute('id')}` : 'iframe';
    root = `page.frameLocator(${js(fsel)})`;
  } else if (rowAnc && bestLoc.tier === 4 && !bestLoc.xpath.startsWith('//*[@data')) {
    const rt = norm(rowAnc.textContent).split(' ').slice(0, 2).join(' ');
    const anchor = Array.from(rowAnc.querySelectorAll('*')).find((n) => n.children.length === 0 && q.includes(norm(n.textContent).toLowerCase()) && norm(n.textContent).length > 2 && norm(n.textContent).toLowerCase() !== (i.text || '').toLowerCase());
    root = `page.getByRole(${js(rowRole)}, { name: ${js(anchor ? norm(anchor.textContent) : rt)} })`;
  } else if (hostAnc) {
    const h = hostAnc;
    const ht = h.getAttribute('data-testid');
    root = ht ? `page.getByTestId(${js(ht)})` : stable(norm(h.getAttribute('id'))) ? `page.locator(${js('#' + h.getAttribute('id'))})` : `page.locator(${js(h.tagName.toLowerCase())})`;
  }
  // Playwright role-name matching is a case-insensitive substring match: make sure it is not ambiguous
  if (pw.startsWith('getByRole') && nm && root === 'page') {
    const lower = nm.toLowerCase();
    const same = all.filter((e) => { const o = info(e); return o.role === i.role && accName(o).toLowerCase().includes(lower); });
    if (same.length > 1) {
      if (rowAnc) {
        const rowLeaves = Array.from(rowAnc.querySelectorAll('*')).filter((n) => n.children.length === 0 && norm(n.textContent).length > 2 && textCount.get(norm(n.textContent)) === 1);
        const anchor = rowLeaves.find((n) => q.includes(norm(n.textContent).toLowerCase())) || rowLeaves[0];
        root = anchor ? `page.getByRole(${js(rowRole)}, { name: ${js(norm(anchor.textContent))} })` : root;
      } else {
        pw = pw.replace(/ \}\)$/, ', exact: true })');
      }
    }
  }
  const playwright = `${root}.${pw}`;

  // iframe: prefix XPath with the frame step so the frame context is explicit
  let bestX = bestLoc.xpath;
  let alts = verified.slice(1).map((l) => l.xpath);
  if (iframeAnc) {
    const fi = QA_ATTRS.map((a) => iframeAnc.getAttribute(a) ? `@${a}=${xq(iframeAnc.getAttribute(a)!)}` : '').find(Boolean) || (iframeAnc.getAttribute('id') ? `@id=${xq(iframeAnc.getAttribute('id')!)}` : '');
    const frameStep = `//iframe${fi ? `[${fi}]` : ''}`;
    const inner = (x: string) => (x.startsWith('//') ? x : `//*[1]${x.startsWith('(') ? '' : '/'}`.length ? x : x);
    const wrap = (x: string) => (x.startsWith('//') ? `${frameStep}${inner(x)}` : x);
    bestX = wrap(bestX);
    alts = alts.map(wrap);
    if (!alts.includes(bestLoc.xpath)) alts.push(bestLoc.xpath);
  }
  alts = alts.filter((x) => x !== bestX && !/^\/\/\w+\[@type=/.test(x)).slice(0, 3);
  if (alts.length < 2 && textOk) {
    const extra = `//*[normalize-space()=${xq(i.text)}]`;
    if (extra !== bestX && !alts.includes(extra) && count(extra).n === 1) alts.push(extra);
  }

  // ---- confidence and explanation
  const base = { 1: 0.99, 2: 0.95, 3: 0.91, 4: 0.88, 5: 0.78, 6: 0.5 }[bestLoc.tier];
  const conf = Math.max(0.3, Math.min(0.99, base - (margin < 1.5 ? 0.12 : margin < 3 ? 0.05 : 0)));
  const strategy = iframeAnc ? 'iFrame Context Traversal' : bestLoc.label;
  const why: Record<number, string> = {
    1: `Found explicit test attribute on the <${tag}>, which ranks #1 for stability and is unaffected by styling or copy changes.`,
    2: `Matched a persistent attribute that is unique in the DOM and is not an auto-generated hash.`,
    3: `Uses the visible text with normalize-space(), which survives whitespace and indentation changes, and is unique in the DOM.`,
    4: `A plain attribute or text locator was not unique, so it is anchored to stable surrounding content and traversed to the <${tag}>.`,
    5: `No unique exact locator existed, so a partial match on a stable prefix / text fragment is used.`,
    6: `No stable attribute, text or anchor made this element unique; a positional locator is the last resort and is fragile. Ask developers to add a data-testid.`,
  };
  let explanation = why[bestLoc.tier];
  if (iframeAnc) explanation += ` The element lives inside an <iframe>, so switch into the frame first (Playwright: frameLocator, Selenium: switchTo().frame()).`;
  if (hostAnc && !iframeAnc) explanation += ` It sits inside the custom element <${hostAnc.tagName.toLowerCase()}>; if that uses a real shadow root, XPath cannot cross it, so prefer the Playwright locator or CSS selector.`;

  return {
    target_functionality: query,
    best_xpath: bestX,
    strategy_used: strategy,
    alternative_xpaths: alts,
    alternative_css_selector: css,
    playwright_semantic_locator: playwright,
    confidence_score: conf.toFixed(2),
    explanation,
  };
}

/** Count how many elements an XPath matches in the given HTML (iframes inflated). -1 = invalid XPath. */
export function countXPathMatches(html: string, xpath: string): number {
  try {
    const dom = new JSDOM(html);
    const doc = dom.window.document;
    doc.querySelectorAll('iframe').forEach((f) => {
      const raw = f.textContent || '';
      if (raw.includes('<')) {
        const holder = doc.createElement('div');
        holder.innerHTML = raw;
        f.textContent = '';
        Array.from(holder.childNodes).forEach((c) => f.appendChild(c));
      }
    });
    return doc.evaluate(xpath, doc, null, dom.window.XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength;
  } catch {
    return -1;
  }
}
